//
//  AppGlint_ZenithTests.swift
//  AppGlint_ZenithTests
//
//  Created by Devanshu Singh(chitkara)     on 18/11/24.
//

import Testing
@testable import AppGlint_Zenith

struct AppGlint_ZenithTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
