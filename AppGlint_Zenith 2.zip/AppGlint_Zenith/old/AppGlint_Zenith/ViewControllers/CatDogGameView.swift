import SwiftUI


struct Card: Identifiable
{
    let id = UUID()
    let name: String
    let imageName: String
    let options: [String]
    let correctAnswer: String
}
struct ContentView: View {
    @State private var currentCard: Card?
    @State private var isPlaying = false
    @State private var score = 0
    @State private var showFeedback = false
    @State private var isCorrect = false
    @State private var usedCards: Set<String> = []
    @State private var gameOver = false
    @State private var questionsAttempted = 0
    
    let cards = [
        Card(name: "Cat",
             imageName: "cat",
             options: ["Cat", "Dog", "Bird", "Fish"],
             correctAnswer: "Cat"),
        Card(name: "Dog",
             imageName: "dog",
             options: ["Rabbit", "Dog", "Cat", "Bird"],
             correctAnswer: "Dog"),
        Card(name: "Bird",
             imageName: "bird",
             options: ["Fish", "Cat", "Bird", "Rabbit"],
             correctAnswer: "Bird"),
        Card(name: "Fish",
             imageName: "fish",
             options: ["Dog", "Fish", "Cat", "Bird"],
             correctAnswer: "Fish"),
        Card(name: "Rabbit",
             imageName: "rabbit",
             options: ["Bird", "Cat", "Dog", "Rabbit"],
             correctAnswer: "Rabbit")
    ]
    
    var body: some View {
        VStack(spacing: 25) {
            if gameOver {
                gameOverView
            } else {
                gamePlayView
            }
        }
        .padding()
    }
    
    var gameOverView: some View {
        VStack(spacing: 30) {
            if score == 5 {
                Image(systemName: "star.fill")
                    .font(.system(size: 100))
                    .foregroundColor(.yellow)
                
                Text("Congratulations!")
                    .font(.system(size: 35, weight: .bold))
                    .foregroundColor(.green)
                
                Text("You got all correct!")
                    .font(.title2)
                    .foregroundColor(.blue)
            } else {
                Text("Game Over!")
                    .font(.system(size: 35, weight: .bold))
                    .foregroundColor(.blue)
                
                Text("Your Score: \(score) out of 5")
                    .font(.title2)
                    .foregroundColor(.orange)
            }
            
            Button(action: {
                startGame()
            }) {
                Text("Play Again")
                    .font(.system(size: 24, weight: .bold))
                    .foregroundColor(.white)
                    .padding(.horizontal, 40)
                    .padding(.vertical, 15)
                    .background(Color.green)
                    .cornerRadius(15)
            }
        }
    }
    
    var gamePlayView: some View {
        VStack(spacing: 25) {
            Text("Find the Animal!")
                .font(.system(size: 35, weight: .bold))
                .foregroundColor(.blue)
            
            if isPlaying, let card = currentCard {
                // Image Display
                Image(card.imageName)
                    .resizable()
                    .scaledToFit()
                    .frame(height: 200)
                    .cornerRadius(15)
                    .shadow(radius: 5)
                    .padding()
                    .background(RoundedRectangle(cornerRadius: 20)
                        .fill(Color.yellow.opacity(0.2)))
                
                // Options Grid
                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 15) {
                    ForEach(card.options, id: \.self) { option in
                        Button(action: {
                            checkAnswer(option, correctAnswer: card.correctAnswer)
                        }) {
                            Text(option)
                                .font(.system(size: 24, weight: .semibold))
                                .foregroundColor(.white)
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color.blue)
                                .cornerRadius(15)
                        }
                        .disabled(showFeedback)
                    }
                }
                .padding(.horizontal)
                
                Text("Question \(questionsAttempted + 1) of 5")
                    .font(.title3)
                    .foregroundColor(.gray)
                
                Text("Score: \(score)")
                    .font(.system(size: 30, weight: .bold))
                    .foregroundColor(.orange)
                    .padding()
                
            } else {
                Button(action: {
                    startGame()
                }) {
                    Text("Start Game")
                        .font(.system(size: 30, weight: .bold))
                        .foregroundColor(.white)
                        .padding(.horizontal, 40)
                        .padding(.vertical, 20)
                        .background(Color.green)
                        .cornerRadius(20)
                }
            }
        }
    }
    
    func checkAnswer(_ selected: String, correctAnswer: String) {
        isCorrect = selected == correctAnswer
        questionsAttempted += 1
        
        if isCorrect {
            score += 1
            if questionsAttempted >= 5 {
                gameOver = true
            } else {
                nextCard()
            }
        } else {
            gameOver = true
        }
    }
    
    func startGame() {
        score = 0
        isPlaying = true
        gameOver = false
        questionsAttempted = 0
        usedCards.removeAll()
        nextCard()
    }
    
    func nextCard() {
        if let newCard = cards.first(where: { !usedCards.contains($0.name) }) {
            currentCard = newCard
            usedCards.insert(newCard.name)
        } else {
            gameOver = true
        }
    }
}

#Preview {
    ContentView()
}
