//
//  ProgressParentViewController.swift
//  AppGlint_Zenith
//
//  Created by Devanshu Singh(chitkara)     on 25/03/25.
//

import UIKit
import SwiftUI

class ProgressParentViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
//        let parentDashboard = ParentalDashboardView()
//        let hostingController = UIHostingController(rootView: parentDashboard)
//
//               // Add the hosting controller's view as a subview
//               addChild(hostingController)
//               view.addSubview(hostingController.view)
//               hostingController.didMove(toParent: self)
//
//               // Set constraints for the SwiftUI view to fill the parent view
//               hostingController.view.translatesAutoresizingMaskIntoConstraints = false
//               NSLayoutConstraint.activate([
//                   hostingController.view.topAnchor.constraint(equalTo: view.topAnchor),
//                   hostingController.view.leadingAnchor.constraint(equalTo: view.leadingAnchor),
//                   hostingController.view.trailingAnchor.constraint(equalTo: view.trailingAnchor),
//                   hostingController.view.bottomAnchor.constraint(equalTo: view.bottomAnchor)
//               ])

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
