import UIKit

class GameCell: UICollectionViewCell {
    static let identifier = "GameCell"
    
    private let containerView: UIView = {
        let view = UIView()
        view.layer.cornerRadius = 24
        view.clipsToBounds = true
        return view
    }()
    
    private let titleLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 42, weight: .bold)
        label.textColor = .white
        label.numberOfLines = 2
        return label
    }()
    
    private let iconView: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        imageView.tintColor = .white
        return imageView
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupViews()
        
        layer.shadowColor = UIColor.black.cgColor
        layer.shadowOffset = CGSize(width: 0, height: 4)
        layer.shadowRadius = 12
        layer.shadowOpacity = 0.1
        layer.masksToBounds = false
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(cellTapped))
        addGestureRecognizer(tapGesture)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupViews() {
        contentView.addSubview(containerView)
        containerView.addSubview(titleLabel)
        containerView.addSubview(iconView)
        
        containerView.translatesAutoresizingMaskIntoConstraints = false
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        iconView.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            containerView.topAnchor.constraint(equalTo: contentView.topAnchor),
            containerView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            containerView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
            containerView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor),
            
            titleLabel.leadingAnchor.constraint(equalTo: containerView.leadingAnchor, constant: 24),
            titleLabel.bottomAnchor.constraint(equalTo: containerView.bottomAnchor, constant: -24),
            titleLabel.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: -80),
            
            iconView.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: -24),
            iconView.bottomAnchor.constraint(equalTo: containerView.bottomAnchor, constant: -24),
            iconView.widthAnchor.constraint(equalToConstant: 48),
            iconView.heightAnchor.constraint(equalToConstant: 48)
        ])
    }
    
    func configure(with game: Games) {
        containerView.backgroundColor = game.backgroundColor
        titleLabel.text = game.title
        iconView.image = game.icon
    }
    func configureRecent(with index: Int) {
        guard let game = UserDataManager.shared.getRecentGame(at: index) else {
            print("Error: No game found at index \(index)")
            return
        }

        containerView.backgroundColor = game.backgroundColor
        titleLabel.text = game.title
        iconView.image = game.icon
    }
    private func findParentViewController() -> UIViewController? {
        var responder: UIResponder? = self
        while let nextResponder = responder?.next {
            if let viewController = nextResponder as? UIViewController {
                return viewController
            }
            responder = nextResponder
        }
        return nil
    }
    @objc private func cellTapped() {
            guard let parentViewController = findParentViewController() else { return }

            let storyboard = UIStoryboard(name: "Bubble", bundle: nil)
            if let bubbleVC = storyboard.instantiateViewController(withIdentifier: "BubbleViewController") as? BubbleViewController {
                bubbleVC.isFavourite = false
                bubbleVC.Gametitle = "Game"
                parentViewController.present(bubbleVC, animated: true, completion: nil)
            }
        }

}
