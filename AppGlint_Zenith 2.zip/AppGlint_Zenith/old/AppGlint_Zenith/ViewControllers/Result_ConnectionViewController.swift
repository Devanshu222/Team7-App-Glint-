//
//  Result_ConnectionViewController.swift
//  AppGlint_Zenith
//
//  Created by Devanshu Singh(chitkara)     on 27/03/25.
//

import UIKit
import SwiftUI

class Result_ConnectionViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        let surveyresultView = SurveyResultView(results:  SurveyResultView(results: [
            SurveyResult(category: "Sensory", score: 8, maxScore: 10),
            SurveyResult(category: "Calming", score: 6, maxScore: 10),
            SurveyResult(category: "Interactive", score: 7, maxScore: 10)
        ]))
        
        // Create a UIHostingController with the SwiftUI view
        let hostingController = UIHostingController(rootView: surveyresultView)
        
        // Add the hosting controller as a child view controller
        addChild(hostingController)
        
        // Add the hosting controller's view to the view hierarchy
        view.addSubview(hostingController.view)
        
        // Set up constraints
        hostingController.view.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            hostingController.view.topAnchor.constraint(equalTo: view.topAnchor),
            hostingController.view.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            hostingController.view.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            hostingController.view.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
