import SwiftUI
import Charts

struct SurveyResultView: View {
    let results: [SurveyResult]
    
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                // Header Section
                VStack(spacing: 10) {
                    Text("Results")
                        .font(.system(size: 28, weight: .bold))
                        .padding(.top, 20)
                    
                    Text("Insights and recommendations for your child's development")
                        .font(.system(size: 16))
                        .foregroundColor(.secondary)
                }
                
                // Data Analysis Section
                VStack(alignment: .leading, spacing: 15) {
                    Text("Data Analysis")
                        .font(.system(size: 20, weight: .bold))
                        .padding(.horizontal)
                    
                    if #available(iOS 16.0, *) {
                        Chart {
                            ForEach(results) { result in
                                BarMark(
                                    x: .value("Category", result.category),
                                    y: .value("Score", result.score)
                                )
                                .foregroundStyle(by: .value("Category", result.category))
                            }
                        }
                        .frame(height: 200)
                        .padding()
                    } else {
                        // Fallback for earlier versions
                        VStack(alignment: .leading) {
                            ForEach(results) { result in
                                Text("• \(result.category): \(getAnalysisText(for: result))")
                                    .font(.system(size: 14))
                                    .padding(.vertical, 4)
                            }
                        }
                        .padding()
                    }
                }
                .padding(.top, 20)
                
                // Recommendations Section
                VStack(alignment: .leading, spacing: 15) {
                    Text("Recommendations")
                        .font(.system(size: 20, weight: .bold))
                        .padding(.horizontal)
                    
                    ForEach(getRecommendations(), id: \.self) { recommendation in
                        RecommendationCard(text: recommendation)
                    }
                }
                .padding(.top, 20)
            }
            .padding(.bottom, 40)
        }
        .background(Color(.systemGroupedBackground))
        .navigationTitle("Survey Analysis")
    }
    
    private func getAnalysisText(for result: SurveyResult) -> String {
        let percentage = Double(result.score) / Double(result.maxScore)
        switch percentage {
        case 0..<0.4:
            return "Needs significant improvement"
        case 0.4..<0.7:
            return "Shows potential, needs more practice"
        case 0.7..<0.9:
            return "Performing well, can still improve"
        default:
            return "Excellent performance"
        }
    }
    
    private func getRecommendations() -> [String] {
        // Generate recommendations based on results
        var recommendations: [String] = []
        
        for result in results {
            let percentage = Double(result.score) / Double(result.maxScore)
            switch percentage {
            case 0..<0.4:
                recommendations.append("Focus more on \(result.category.lowercased()) activities")
            case 0.4..<0.7:
                recommendations.append("Practice \(result.category.lowercased()) exercises regularly")
            case 0.7..<0.9:
                recommendations.append("Maintain \(result.category.lowercased()) practice routine")
            default:
                recommendations.append("Continue excelling in \(result.category.lowercased()) activities")
            }
        }
        
        return recommendations
    }
}

// MARK: - Subviews

struct RecommendationCard: View {
    let text: String
    
    var body: some View {
        HStack {
            Image(systemName: "lightbulb.fill")
                .foregroundColor(.yellow)
                .padding(.trailing, 8)
            
            Text(text)
                .font(.system(size: 14))
                .fixedSize(horizontal: false, vertical: true)
            
            Spacer()
        }
        .padding()
        .background(Color(.systemBackground))
        .cornerRadius(10)
        .padding(.horizontal)
    }
}

// MARK: - Data Models

struct SurveyResult: Identifiable {
    let id = UUID()
    let category: String
    let score: Int
    let maxScore: Int
}

struct SurveyResultView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            SurveyResultView(results: [
                SurveyResult(category: "Sensory", score: 8, maxScore: 10),
                SurveyResult(category: "Calming", score: 6, maxScore: 10),
                SurveyResult(category: "Interactive", score: 7, maxScore: 10)
            ])
        }
    }
} 
//import SwiftUI
//import Charts
//
//struct SurveyResultView: View {
//    let surveyAnswers: [SurveyAnswer] // Assuming you pass survey answers
//
//    var body: some View {
//        ScrollView {
//            VStack(spacing: 20) {
//                // Header Section
//                VStack(spacing: 10) {
//                    Text("Results")
//                        .font(.system(size: 28, weight: .bold))
//                        .padding(.top, 20)
//
//                    Text("Insights and recommendations for your child's development")
//                        .font(.system(size: 16))
//                        .foregroundColor(.secondary)
//                }
//
//                // Data Analysis Section
//                VStack(alignment: .leading, spacing: 15) {
//                    Text("Data Analysis")
//                        .font(.system(size: 20, weight: .bold))
//                        .padding(.horizontal)
//
//                    if #available(iOS 16.0, *) {
//                        Chart {
//                            ForEach(calculateCategoryScores()) { result in
//                                BarMark(
//                                    x: .value("Category", result.category),
//                                    y: .value("Score", result.score)
//                                )
//                                .foregroundStyle(by: .value("Category", result.category))
//                            }
//                        }
//                        .frame(height: 200)
//                        .padding()
//                    } else {
//                        // Fallback for earlier versions
//                        VStack(alignment: .leading) {
//                            ForEach(calculateCategoryScores()) { result in
//                                Text("• \(result.category): \(getAnalysisText(for: result))")
//                                    .font(.system(size: 14))
//                                    .padding(.vertical, 4)
//                            }
//                        }
//                        .padding()
//                    }
//                }
//                .padding(.top, 20)
//
//                // Recommendations Section
//                VStack(alignment: .leading, spacing: 15) {
//                    Text("Recommendations")
//                        .font(.system(size: 20, weight: .bold))
//                        .padding(.horizontal)
//
//                    ForEach(getRecommendations(), id: \.self) { recommendation in
//                        RecommendationCard(text: recommendation)
//                    }
//                }
//                .padding(.top, 20)
//            }
//            .padding(.bottom, 40)
//        }
//        .background(Color(.systemGroupedBackground))
//        .navigationTitle("Survey Analysis")
//    }
//
//    private func calculateCategoryScores() -> [SurveyResult] {
//        var scores: [String: Int] = [
//            "Calming": 0,
//            "Interactive": 0,
//            "Social": 0,
//            "Sensory": 0
//        ]
//
//        for answer in surveyAnswers {
//            let question = AutismSurveyManager.questions[answer.questionId]
//            if answer.selectedOption == question.correctAnswerIndex {
//                scores[question.category.rawValue]! += 1
//            }
//        }
//
//        return scores.map { SurveyResult(category: $0.key, score: $0.value, maxScore: AutismSurveyManager.questions.filter { $0.category.rawValue == $0.key }.count)}
//    }
//
//    private func getAnalysisText(for result: SurveyResult) -> String {
//        let percentage = Double(result.score) / Double(result.maxScore)
//        switch percentage {
//        case 0..<0.4:
//            return "Needs significant improvement"
//        case 0.4..<0.7:
//            return "Shows potential, needs more practice"
//        case 0.7..<0.9:
//            return "Performing well, can still improve"
//        default:
//            return "Excellent performance"
//        }
//    }
//
//    private func getRecommendations() -> [String] {
//        var recommendations: [String] = []
//        let categoryResults = calculateCategoryScores()
//
//        for result in categoryResults {
//            let percentage = Double(result.score) / Double(result.maxScore)
//            switch percentage {
//            case 0..<0.4:
//                recommendations.append("Focus more on \(result.category.lowercased()) activities")
//            case 0.4..<0.7:
//                recommendations.append("Practice \(result.category.lowercased()) exercises regularly")
//            case 0.7..<0.9:
//                recommendations.append("Maintain \(result.category.lowercased()) practice routine")
//            default:
//                recommendations.append("Continue excelling in \(result.category.lowercased()) activities")
//            }
//        }
//
//        return recommendations
//    }
//}
//
//// MARK: - Subviews
//
//struct RecommendationCard: View {
//    let text: String
//
//    var body: some View {
//        HStack {
//            Image(systemName: "lightbulb.fill")
//                .foregroundColor(.yellow)
//                .padding(.trailing, 8)
//
//            Text(text)
//                .font(.system(size: 14))
//                .fixedSize(horizontal: false, vertical: true)
//
//            Spacer()
//        }
//        .padding()
//        .background(Color(.systemBackground))
//        .cornerRadius(10)
//        .padding(.horizontal)
//    }
//}
//
//// MARK: - Data Models
//
//struct SurveyResult: Identifiable {
//    let id = UUID()
//    let category: String
//    let score: Int
//    let maxScore: Int
//}
//
//struct SurveyAnswer {
//    let questionId: Int
//    let selectedOption: Int?
//    let isTrue: Bool?
//    let answerText: String?
//}
//
//// Assuming AutismSurveyManager.questions is defined somewhere
////enum Category: String {
////    case calming = "Calming"
////    case interactive = "Interactive"
////    case social = "Social"
////    case sensory = "Sensory"
////}
////
////struct Question {
////    let category: Category
////    let correctAnswerIndex: Int
////}
////
////struct AutismSurveyManager {
////    static let questions: [Question] = [
////        Question(category: .calming, correctAnswerIndex: 0),
////        Question(category: .interactive, correctAnswerIndex: 1),
////        Question(category: .social, correctAnswerIndex: 2),
////        Question(category: .sensory, correctAnswerIndex: 3),
////        Question(category: .calming, correctAnswerIndex: 0),
////        Question(category: .interactive, correctAnswerIndex: 1),
////        Question(category: .social, correctAnswerIndex: 2),
////        Question(category: .sensory, correctAnswerIndex: 3),
////        Question(category: .calming, correctAnswerIndex: 0),
////        Question(category: .interactive, correctAnswerIndex: 1),
////    ]
////}
////
////struct SurveyResultView_Previews: PreviewProvider {
////    static var previews: some View {
////        NavigationView {
////            SurveyResultView(surveyAnswers: [
////                SurveyAnswer(questionId: 0, selectedOption: 0, isTrue: nil, answerText: nil),
////                SurveyAnswer(questionId: 1, selectedOption: 1, isTrue: nil, answerText: nil),
////                SurveyAnswer(questionId: 2, selectedOption: 2, isTrue: nil, answerText: nil),
////                SurveyAnswer(questionId: 3, selectedOption: 3, isTrue: nil, answerText: nil),
////                SurveyAnswer(questionId: 4, selectedOption: 0, isTrue: nil, answerText: nil),
////                SurveyAnswer(questionId: 5, selectedOption: 1, isTrue: nil, answerText: nil),
////                SurveyAnswer(questionId: 6, selectedOption: 2, isTrue: nil, answerText: nil),
////                SurveyAnswer(questionId: 7, selectedOption: 3, isTrue: nil, answerText: nil),
////                SurveyAnswer(questionId: 8, selectedOption: 0, isTrue: nil, answerText: nil),
////                SurveyAnswer(questionId: 9, selectedOption: 1, isTrue: nil, answerText: nil),
////            ])
//
//
