import SwiftUI
import Charts

struct ParentalDashboard: View {
    @State private var selectedTimeFrame = 0
    @State private var timeFrames = ["D", "W", "Y"]
    
    var body: some View {
        NavigationView {
            List {
                Section(header: Text("Progress Tracking")) {
                    NavigationLink(destination: ProgressTrackingDetailView()) {
                        VStack(spacing: 16) {
                            HStack(alignment: .top, spacing: 30) {
                                VStack(alignment: .leading, spacing: 12) {
                                    Text("Sensory")
                                        .font(.system(size: 18, weight: .bold))
                                        .foregroundColor(.red)
                                    
                                    Text("50%")
                                        .font(.system(size: 20, weight: .bold))
                                    
                                    Text("Calming")
                                        .font(.system(size: 18, weight: .bold))
                                        .foregroundColor(.blue)
                                    
                                    Text("20%")
                                        .font(.system(size: 20, weight: .bold))
                                    
                                    Text("Interactive")
                                        .font(.system(size: 18, weight: .bold))
                                        .foregroundColor(.green)
                                    
                                    Text("30%")
                                        .font(.system(size: 20, weight: .bold))
                                }
                                .frame(width: 100)
                                
                                LineProgressView()
                                    .frame(maxWidth: .infinity)
                            }
                            .padding(.vertical, 10)
                        }
                    }
                }
                
                Section(header: Text("Structured Learning")) {
                    NavigationLink(destination: ScheduleView()) {
                        Text("Child's Schedule")
                            .font(.system(size: 18))
                    }
                    
                    NavigationLink(destination: PlayedTodayView()) {
                        Text("Played Today")
                            .font(.system(size: 18))
                    }
                }
                
                Section(header: Text("Time Limit")) {
                    TimeLimitView()
                }
            }
            .listStyle(InsetGroupedListStyle())
            .navigationTitle("Parental Dashboard")
        }
    }
}

struct LineProgressView: View {
    var body: some View {
        // Placeholder for your custom line progress view
        Rectangle()
            .fill(Color.clear)
    }
}

struct TimeLimitView: View {
    @State private var selectedTime: Date = Date()
    @State private var isTimerRunning = false
    
    var body: some View {
        HStack {
            DatePicker("", selection: $selectedTime, displayedComponents: .hourAndMinute)
                .datePickerStyle(WheelDatePickerStyle())
                .frame(width: 187)
            
            Spacer()
            
            Button(action: {
                isTimerRunning.toggle()
            }) {
                Text(isTimerRunning ? "Stop" : "Start")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundColor(.white)
                    .frame(width: 110, height: 40)
                    .background(isTimerRunning ? Color.red : Color.green)
                    .cornerRadius(8)
            }
        }
        .padding(.vertical, 10)
    }
}

struct ProgressTrackingDetailView: View {
    @State private var selectedTimeFrame = 0
    
    var body: some View {
        List {
            Section {
                VStack(spacing: 20) {
                    Picker("Time Frame", selection: $selectedTimeFrame) {
                        Text("D").tag(0)
                        Text("W").tag(1)
                        Text("Y").tag(2)
                    }
                    .pickerStyle(SegmentedPickerStyle())
                    .padding(.horizontal)
                    
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Daily Goals")
                            .font(.system(size: 13))
                            .foregroundColor(.gray)
                        
                        HStack {
                            Text("50%")
                                .font(.system(size: 17, weight: .bold))
                            Text("Completed")
                                .foregroundColor(.gray)
                        }
                        
                        Text("Today")
                            .font(.system(size: 13))
                            .foregroundColor(.gray)
                    }
                    .padding(.horizontal)
                    
                    // Add your chart view here
                }
            }
            
            Section(header: Text("Highlights")) {
                VStack(alignment: .leading, spacing: 16) {
                    Text("🔥 Tasks")
                        .font(.system(size: 18, weight: .bold))
                    
                    Text("On an average, your tasks this month are about the same as last month.")
                        .font(.system(size: 18, weight: .bold))
                        .fixedSize(horizontal: false, vertical: true)
                }
                .padding(.vertical, 8)
                
                HStack {
                    Text("5")
                        .font(.system(size: 38, weight: .bold))
                    
                    Text("tasks/day")
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundColor(.gray)
                    
                    Spacer()
                    
                    Text("September")
                        .font(.system(size: 30, weight: .bold))
                }
                .padding(.vertical, 8)
            }
        }
        .listStyle(InsetGroupedListStyle())
        .navigationTitle("Progress Tracking")
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct ScheduleView: View {
    var body: some View {
        Text("Schedule View")
    }
}

struct PlayedTodayView: View {
    var body: some View {
        Text("Played Today View")
    }
}

struct ParentalDashboard_Previews: PreviewProvider {
    static var previews: some View {
        ParentalDashboard()
    }
} 