    //
//  data1.swift
//  AppGlint_Zenith
//
//  Created by SIMRAN BHARDWAJ on 20/01/25.
//

var articleData: [Article] = [
    Article(id: 1, title: "Dondochakka", description: "hadsfs", imageURL: "Resource_1", category: .autism)
]

var categoryData: [ContactInfo] = [
    ContactInfo(id: 1, name: "Simran", type: .doctor, phoneNumber: "976", address: "sector 44", location: "chanakyapuri")
]

var users : [User] = [
    User(id: 1, name: "Simran", email: "simran@gmail.com"),
]

