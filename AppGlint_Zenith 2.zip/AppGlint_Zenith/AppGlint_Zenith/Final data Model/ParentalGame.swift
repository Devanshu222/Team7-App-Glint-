import Foundation

struct Step: Codable { // Conforming to Codable for easy storage
    let title: String
    let subtitle: String
    let image: String // Image name or SF Symbol name
    var markedDone: Bool
}

var steps: [Step] = loadSteps()

func saveSteps() {
    if let encodedData = try? JSONEncoder().encode(steps) {
        UserDefaults.standard.set(encodedData, forKey: "stepsData")
    }
}

func loadSteps() -> [Step] {
    if let savedData = UserDefaults.standard.data(forKey: "stepsData"),
       let decodedSteps = try? JSONDecoder().decode([Step].self, from: savedData) {
        return decodedSteps
    }
    return [
        Step(title: "Give your child a toy",
             subtitle: "Choose a favorite toy that your child enjoys playing with",
             image: "home.fill", markedDone: false),
        Step(title: "Create a calm environment",
             subtitle: "Find a quiet space free from distractions to help your child focus on the activity",
             image: "star.fill", markedDone: false),
        Step(title: "Let him play!",
             subtitle: "Find a quiet space free from distractions to help your child focus on the activity",
             image: "star.fill", markedDone: false)
    ]
}
