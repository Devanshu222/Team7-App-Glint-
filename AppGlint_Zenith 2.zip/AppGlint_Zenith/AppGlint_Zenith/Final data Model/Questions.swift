//
//  Questions.swift
//  AppGlint_Zenith
//
//  Created by Devanshu Singh(chitkara)     on 12/12/24.
//
enum QuestionCategory {
    case calming
    case interactive
    case sensory
}
struct Question {
let text: String
let options: [String]
let type: QuestionType
let category: QuestionCategory
}

enum QuestionType {
case multipleChoice
}

class AutismSurveyManager {
    static let questions = [
        Question(
            text: "Does your child cover their ears in response to loud noises?",
            options: ["Yes", "Sometimes", "No"],
            type: .multipleChoice, category: .sensory
        ),
        Question(
            text: "Does your child seem bothered by certain textures (e.g., clothing, food)?",
            options: ["Yes", "Sometimes", "No"],
            type: .multipleChoice, category: .sensory
        ),
        Question(
            text: "Does your child become distressed in bright lights or noisy environments?",
            options: ["Yes", "Sometimes", "No"],
            type: .multipleChoice, category: .sensory
        ),
        Question(
            text: "Does your child seek out sensory input (e.g., spinning, staring at moving objects, touching different textures)?",
            options: ["Yes", "Sometimes", "No"],
            type: .multipleChoice, category: .sensory
        ),
        Question(
            text: "Does your child engage in repetitive movements (e.g., hand-flapping, rocking)?",
            options: ["Yes", "Sometimes", "No"],
            type: .multipleChoice, category: .calming
        ),
        Question(
            text: "Does your child insist on following specific routines and become upset when disrupted?",
            options: ["Yes", "Sometimes", "No"],
            type: .multipleChoice, category: .calming
        ),
        Question(
            text: "Does your child show an unusual attachment to certain objects (e.g., carrying the same toy everywhere)?",
            options: ["Yes", "Sometimes", "No"],
            type: .multipleChoice, category: .calming
        ),
        Question(
            text: "Does your child focus intensely on a particular object or activity while ignoring others?",
            options: ["Yes", "Sometimes", "No"],
            type: .multipleChoice, category: .calming
        ),
        Question(
            text: "Does your child avoid certain physical sensations, such as disliking being touched or hugged?",
            options: ["Yes", "Sometimes", "No"],
            type: .multipleChoice, category: .calming
        ),
        Question(
            text: "Does your child respond to their name when called?",
            options: ["Yes", "Sometimes", "No"],
            type: .multipleChoice, category: .interactive
        ),
        Question(
            text: "Does your child make eye contact during interactions?",
            options: ["Yes", "Sometimes", "No"],
            type: .multipleChoice, category: .interactive
        ),
        Question(
            text: "Does your child initiate interactions with others (e.g., bringing a toy to show, starting a conversation)?",
            options: ["Yes", "Sometimes", "No"],
            type: .multipleChoice, category: .interactive
        ),
        Question(
            text: "Does your child engage in pretend play (e.g., feeding a doll, playing house)?",
            options: ["Yes", "Sometimes", "No"],
            type: .multipleChoice, category: .interactive
        ),
        Question(
            text: "Does your child show interest in playing with other children?",
            options: ["Yes", "Sometimes", "No"],
            type: .multipleChoice, category: .interactive
        ),
        Question(
            text: "Do you feel your child is more sensitive to sensory experiences than other children their age?",
            options: ["Yes", "Sometimes", "No"],
            type: .multipleChoice, category: .sensory
        )
    ]

    var currentQuestionIndex = 0
    var totalCorrectAnswers = 0
    
    var currentQuestion: Question {
        return AutismSurveyManager.questions[currentQuestionIndex]
    }
    
    var isLastQuestion: Bool {
        return currentQuestionIndex == AutismSurveyManager.questions.count - 1
    }
    
    func nextQuestion() {
        currentQuestionIndex += 1
    }
    
    func calculateScore() -> Int {
        return totalCorrectAnswers
    }
    
//    func checkAnswer(_ selectedIndex: Int) -> Bool {
//        let isCorrect = selectedIndex == currentQuestion.correctAnswerIndex
//        if isCorrect {
//            totalCorrectAnswers += 1
//        }
//        return isCorrect
//    }
    
    
}



