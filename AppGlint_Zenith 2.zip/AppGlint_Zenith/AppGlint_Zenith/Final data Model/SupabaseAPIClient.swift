//
//  SupabaseAPIClient.swift
//  AppGlint_Zenith
//
//  Created by student-2 on 31/03/25.
//


import Foundation
import Supabase

class SupabaseAPIClient {
    private init() {}
    static var shared: SupabaseAPIClient = SupabaseAPIClient()
    let supabase = SupabaseClient(
      supabaseURL: URL(string: "https://cfmtzjmkhdowjdsasokv.supabase.co")!,
      supabaseKey: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNmbXR6am1raGRvd2pkc2Fzb2t2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDEzMTg2MTQsImV4cCI6MjA1Njg5NDYxNH0.ozL5d3CVWOYDPm9monB7bbDyVMQ7kfNyC2VY8zkhxqo"
    )
}
