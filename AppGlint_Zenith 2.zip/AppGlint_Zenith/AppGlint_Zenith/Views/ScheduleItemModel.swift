//import SwiftUI
//import UIKit
//import Combine
//
//// Model for SwiftUI implementation
//struct ScheduleItemModel: Identifiable {
//    let id = UUID()
//    let title: String
//    let subtitle: String
//    let image: UIImage
//    let icon: UIImage
//    let backgroundColor: UIColor
//    let category: Category
//    var isFavourite: Bool
//    var isParental: Bool
//    var time: Date
//    var hasBeenPlayed: Bool = false
//    
//    // Convert from UIKit model
//    init(from item: ScheduleItem) {
//        self.title = item.title
//        self.subtitle = item.subtitle
//        self.image = item.image
//        self.icon = item.icon
//        self.backgroundColor = item.backgroundColor
//        self.category = item.category
//        self.isFavourite = item.isFavourite
//        self.isParental = item.isParental
//        self.time = item.time
//    }
//    
//    // Convert back to UIKit model
//    func toScheduleItem() -> ScheduleItem {
//        return ScheduleItem(
//            title: title,
//            subtitle: subtitle,
//            image: image,
//            icon: icon,
//            backgroundColor: backgroundColor,
//            category: category,
//            isFavourite: isFavourite,
//            isParental: isParental,
//            time: time
//        )
//    }
//}
//
//// ViewModel to handle business logic
//class ScheduleViewModel: ObservableObject {
//    @Published var scheduleItems: [ScheduleItemModel] = []
//    private var cancelables = Set<AnyCancellable>()
//    
//    init() {
//        loadInitialData()
//        setupNotifications()
//    }
//    
//    private func loadInitialData() {
//        let uikitItems = convertToScheduleItems(from: schedule)
//        scheduleItems = uikitItems.map { ScheduleItemModel(from: $0) }
//    }
//    
//    private func setupNotifications() {
//        NotificationCenter.default.publisher(for: NSNotification.Name("ScheduleUpdated"))
//            .sink { [weak self] _ in
//                self?.loadInitialData()
//            }
//            .store(in: &cancelables)
//    }
//    
//    func addItem(_ item: ScheduleItemModel) {
//        scheduleItems.append(item)
//        schedule.append(Activites(
//            title: item.title,
//            subtitle: item.subtitle,
//            image: item.image,
//            icon: item.icon,
//            backgroundColor: item.backgroundColor,
//            category: item.category,
//            isFavourite: item.isFavourite,
//            isParental: item.isParental
//        ))
//        scheduleItems.sort { $0.time < $1.time }
//        NotificationCenter.default.post(name: NSNotification.Name("ScheduleUpdated"), object: nil)
//    }
//    
//    func removeItem(at offsets: IndexSet) {
//        let itemsToRemove = offsets.map { scheduleItems[$0] }
//        
//        for item in itemsToRemove {
//            schedule.removeAll {
//                $0.title == item.title && $0.subtitle == item.subtitle
//            }
//        }
//        
//        scheduleItems.remove(atOffsets: offsets)
//        NotificationCenter.default.post(name: NSNotification.Name("ScheduleUpdated"), object: nil)
//    }
//    
//    func markAsPlayed(_ item: ScheduleItemModel) {
//        if let index = scheduleItems.firstIndex(where: { $0.id == item.id }) {
//            scheduleItems[index].hasBeenPlayed = true
//        }
//    }
//}
//
//// Create our own protocol with a different name to avoid conflicts
//protocol SwiftUIBridgeDelegate: AnyObject {
//    func didAddScheduleItem(_ item: ScheduleItem)
//}
//
//// UIKit Controller wrapper for SwiftUI
//struct ScheduleViewControllerRepresentable: UIViewControllerRepresentable {
//    @EnvironmentObject var viewModel: ScheduleViewModel
//    var onAddTapped: () -> Void
//    
//    func makeUIViewController(context: Context) -> ScheduleViewController {
//        let storyboard = UIStoryboard(name: "Main", bundle: nil)
//        let controller = storyboard.instantiateViewController(withIdentifier: "ScheduleViewController") as! ScheduleViewController
//        controller.bridgeDelegate = context.coordinator
//        return controller
//    }
//    
//    func updateUIViewController(_ uiViewController: ScheduleViewController, context: Context) {
//        // Update UIKit view from SwiftUI state if needed
//        uiViewController.scheduleItems = viewModel.scheduleItems.map { $0.toScheduleItem() }
//        uiViewController.tableView.reloadData()
//    }
//    
//    func makeCoordinator() -> Coordinator {
//        Coordinator(self)
//    }
//    
//    class Coordinator: NSObject, SwiftUIBridgeDelegate {
//        var parent: ScheduleViewControllerRepresentable
//        
//        init(_ parent: ScheduleViewControllerRepresentable) {
//            self.parent = parent
//        }
//        
//        func didAddScheduleItem(_ item: ScheduleItem) {
//            let swiftUIItem = ScheduleItemModel(from: item)
//            parent.viewModel.addItem(swiftUIItem)
//        }
//    }
//}
//
//// Extension to add our bridge delegate to the UIKit controller
//extension ScheduleViewController {
//    var bridgeDelegate: SwiftUIBridgeDelegate? {
//        get {
//            return objc_getAssociatedObject(self, &AssociatedKeys.bridgeDelegateKey) as? SwiftUIBridgeDelegate
//        }
//        set {
//            objc_setAssociatedObject(self, &AssociatedKeys.bridgeDelegateKey, newValue, .OBJC_ASSOCIATION_RETAIN_NONATOMIC)
//        }
//    }
//    
//    // Bridge between original delegate method and our SwiftUI bridge
//    @objc func notifyBridgeDelegateOfNewItem(_ item: ScheduleItem) {
//        bridgeDelegate?.didAddScheduleItem(item)
//    }
//}
//
//private struct AssociatedKeys {
//    static var bridgeDelegateKey = "ScheduleViewController.bridgeDelegateKey"
//}
//
//// Extend the original PickerViewControllerDelegate handler in ScheduleViewController
//extension ScheduleViewController {
//    // Add this method to override or extend the existing didAddScheduleItem functionality
//    @objc func didAddScheduleItemExtended(_ item: ScheduleItem) {
//        // Call the original implementation if it exists
//        self.didAddScheduleItem(item)
//        
//        // Also notify our bridge delegate
//        self.bridgeDelegate?.didAddScheduleItem(item)
//    }
//    
//    // Method swizzling setup - call this in viewDidLoad
//    func setupBridging() {
//        // This is a simple way to hook into the existing delegate method
//        NotificationCenter.default.addObserver(
//            self,
//            selector: #selector(notifyBridgeDelegateOfNewItem(_:)),
//            name: NSNotification.Name("ItemAdded"),
//            object: nil
//        )
//    }
//}
//
//// SwiftUI Schedule Item Row
//struct ScheduleItemRow: View {
//    let item: ScheduleItemModel
//    
//    private let dateFormatter: DateFormatter = {
//        let formatter = DateFormatter()
//        formatter.timeStyle = .short
//        return formatter
//    }()
//    
//    var body: some View {
//        HStack {
//            Image(uiImage: item.icon)
//                .resizable()
//                .frame(width: 40, height: 40)
//                .background(Color(item.backgroundColor))
//                .cornerRadius(8)
//            
//            VStack(alignment: .leading) {
//                Text(item.title)
//                    .font(.headline)
//                Text(item.subtitle)
//                    .font(.subheadline)
//                    .foregroundColor(.secondary)
//            }
//            
//            Spacer()
//            
//            Text(dateFormatter.string(from: item.time))
//                .font(.caption)
//                .foregroundColor(.secondary)
//            
//            if item.hasBeenPlayed {
//                Image(systemName: "checkmark.circle.fill")
//                    .foregroundColor(.green)
//            }
//        }
//        .padding(.vertical, 4)
//    }
//}
//
//// SwiftUI Activity Picker View
//struct ActivityPickerView: View {
//    var onAdd: (ScheduleItemModel) -> Void
//    @Environment(\.presentationMode) var presentationMode
//    @State private var selectedActivity: Activites?
//    @State private var selectedTime = Date()
//    
//    var body: some View {
//        NavigationView {
//            Form {
//                Section(header: Text("Select Activity")) {
//                    List(schedule, id: \.title) { activity in
//                        Button(action: {
//                            selectedActivity = activity
//                        }) {
//                            HStack {
//                                Image(uiImage: activity.icon)
//                                    .resizable()
//                                    .frame(width: 30, height: 30)
//                                    .background(Color(activity.backgroundColor))
//                                    .cornerRadius(6)
//                                
//                                Text(activity.title)
//                                
//                                Spacer()
//                                
//                                if selectedActivity?.title == activity.title {
//                                    Image(systemName: "checkmark")
//                                        .foregroundColor(.blue)
//                                }
//                            }
//                        }
//                    }
//                }
//                
//                Section(header: Text("Select Time")) {
//                    DatePicker("Time", selection: $selectedTime, displayedComponents: .hourAndMinute)
//                }
//                
//                Section {
//                    Button("Add to Schedule") {
//                        if let activity = selectedActivity {
//                            let calendar = Calendar.current
//                            let hour = calendar.component(.hour, from: selectedTime)
//                            let minute = calendar.component(.minute, from: selectedTime)
//                            
//                            let scheduledTime = calendar.date(
//                                bySettingHour: hour,
//                                minute: minute,
//                                second: 0,
//                                of: Date()
//                            ) ?? Date()
//                            
//                            let scheduleItem = ScheduleItem(
//                                title: activity.title,
//                                subtitle: activity.subtitle,
//                                image: activity.image,
//                                icon: activity.icon,
//                                backgroundColor: activity.backgroundColor,
//                                category: activity.category,
//                                isFavourite: activity.isFavourite,
//                                isParental: activity.isParental,
//                                time: scheduledTime
//                            )
//                            
//                            onAdd(ScheduleItemModel(from: scheduleItem))
//                        }
//                    }
//                    .disabled(selectedActivity == nil)
//                }
//            }
//            .navigationTitle("Add Activity")
//            .navigationBarItems(trailing: Button("Cancel") {
//                presentationMode.wrappedValue.dismiss()
//            })
//        }
//    }
//}
//
//// For using the existing UIKit controller in SwiftUI
//struct UIKitScheduleView: View {
//    @EnvironmentObject private var viewModel: ScheduleViewModel
//    @State private var showingAddSheet = false
//    
//    var body: some View {
//        ScheduleViewControllerRepresentable(onAddTapped: {
//            showingAddSheet = true
//        })
//        .environmentObject(viewModel)
//        .sheet(isPresented: $showingAddSheet) {
//            ActivityPickerView(onAdd: { item in
//                viewModel.addItem(item)
//                showingAddSheet = false
//            })
//        }
//    }
//}
