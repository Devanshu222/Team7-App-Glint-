////
////  PlayedTodayView.swift
////  AppGlint_Zenith
////
////  Created by Devanshu Singh(chitkara)     on 04/04/25.
////
//
//import SwiftUI
//
//// MARK: - Models
//struct ScheduleItem: Identifiable, Equatable {
//    var id = UUID()
//    var title: String
//    var subtitle: String
//    var image: String // Using String instead of UIImage for SwiftUI compatibility
//    var icon: String // Using String instead of UIImage for SwiftUI compatibility
//    var backgroundColor: Color // Using Color instead of UIColor
//    var category: Category
//    var isFavorite: Bool
//    var isParental: Bool
//    var time: Date
//    
//    static func == (lhs: ScheduleItem, rhs: ScheduleItem) -> Bool {
//        return lhs.title == rhs.title && lhs.subtitle == rhs.subtitle
//    }
//}
//
//struct Activity {
//    var title: String
//    var subtitle: String
//    var image: String
//    var icon: String
//    var backgroundColor: Color
//    var category: Category
//    var isFavorite: Bool
//    var isParental: Bool
//}
//
//enum Category {
//    case study, play, exercise, rest // Add your categories here
//}
//
//// MARK: - ViewModel
//class ScheduleViewModel: ObservableObject {
//    @Published var scheduleItems: [ScheduleItem] = []
//    
//    init() {
//        loadSampleData()
//    }
//    
//    private var activities: [Activity] = [] // This would store your sample activities
//    
//    func loadSampleData() {
//        // Load your sample activities here
//        scheduleItems = convertToScheduleItems(from: activities)
//    }
//    
//    func convertToScheduleItems(from activities: [Activity]) -> [ScheduleItem] {
//        var items: [ScheduleItem] = []
//        let calendar = Calendar.current
//        let now = Date()
//        var currentTime = calendar.date(bySettingHour: 8, minute: 0, second: 0, of: now)!
//        
//        for activity in activities {
//            let scheduleItem = ScheduleItem(
//                title: activity.title,
//                subtitle: activity.subtitle,
//                image: activity.image,
//                icon: activity.icon,
//                backgroundColor: activity.backgroundColor,
//                category: activity.category,
//                isFavorite: activity.isFavorite,
//                isParental: activity.isParental,
//                time: currentTime
//            )
//            
//            items.append(scheduleItem)
//            currentTime = calendar.date(byAdding: .minute, value: 90, to: currentTime)!
//        }
//        
//        return items
//    }
//    
//    func addItem(_ item: ScheduleItem) {
//        if !scheduleItems.contains(where: { $0.title == item.title && $0.subtitle == item.subtitle }) {
//            scheduleItems.append(item)
//            
//            // Also add to the activities array
//            activities.append(Activity(
//                title: item.title,
//                subtitle: item.subtitle,
//                image: item.image,
//                icon: item.icon,
//                backgroundColor: item.backgroundColor,
//                category: item.category,
//                isFavorite: item.isFavorite,
//                isParental: item.isParental
//            ))
//            
//            // Sort by time
//            scheduleItems.sort { $0.time < $1.time }
//            
//            // Post notification (consider using Combine for this in a real app)
//            NotificationCenter.default.post(name: NSNotification.Name("ScheduleUpdated"), object: nil)
//        }
//    }
//    
//    func removeItem(at indexSet: IndexSet) {
//        let removedItems = indexSet.map { scheduleItems[$0] }
//        scheduleItems.remove(atOffsets: indexSet)
//        
//        // Also remove from activities array
//        for item in removedItems {
//            activities.removeAll { $0.title == item.title && $0.subtitle == item.subtitle }
//        }
//        
//        // Post notification
//        NotificationCenter.default.post(name: NSNotification.Name("ScheduleUpdated"), object: nil)
//    }
//}
//
//// MARK: - Views
//struct ScheduleView: View {
//    @StateObject private var viewModel = ScheduleViewModel()
//    @State private var showingAddSheet = false
//    
//    var body: some View {
//        NavigationView {
//            List {
//                ForEach(viewModel.scheduleItems) { item in
//                    ScheduleItemRow(item: item)
//                }
//                .onDelete { indexSet in
//                    viewModel.removeItem(at: indexSet)
//                }
//            }
//            .navigationTitle("Schedule")
//            .toolbar {
//                ToolbarItem(placement: .navigationBarTrailing) {
//                    Button(action: {
//                        showingAddSheet = true
//                    }) {
//                        Image(systemName: "plus")
//                    }
//                }
//            }
//            .sheet(isPresented: $showingAddSheet) {
//                ActivityPickerView(onAdd: { item in
//                    viewModel.addItem(item)
//                    showingAddSheet = false
//                })
//            }
//        }
//    }
//}
//
//struct ScheduleItemRow: View {
//    let item: ScheduleItem
//    
//    private var timeFormatted: String {
//        let formatter = DateFormatter()
//        formatter.timeStyle = .short
//        return formatter.string(from: item.time)
//    }
//    
//    var body: some View {
//        HStack {
//            Image(item.icon)
//                .resizable()
//                .frame(width: 40, height: 40)
//                .background(item.backgroundColor)
//                .clipShape(Circle())
//                .padding(.trailing, 10)
//            
//            VStack(alignment: .leading) {
//                Text(item.title)
//                    .font(.headline)
//                Text(item.subtitle)
//                    .font(.subheadline)
//                    .foregroundColor(.secondary)
//            }
//            
//            Spacer()
//            
//            Text(timeFormatted)
//                .font(.caption)
//                .foregroundColor(.secondary)
//            
//            if item.isFavorite {
//                Image(systemName: "star.fill")
//                    .foregroundColor(.yellow)
//            }
//            
//            if item.isParental {
//                Image(systemName: "person.2.fill")
//                    .foregroundColor(.blue)
//            }
//        }
//        .padding(.vertical, 8)
//    }
//}
//
//struct ActivityPickerView: View {
//    @Environment(\.dismiss) private var dismiss
//    @State private var selectedActivity: Activity?
//    @State private var selectedTime = Date()
//    
//    var onAdd: (ScheduleItem) -> Void
//    
//    // Sample activities for the picker
//    private let activities: [Activity] = [
//        // You would populate this with your actual activities
//    ]
//    
//    var body: some View {
//        NavigationView {
//            Form {
//                Section(header: Text("Select Activity")) {
//                    ForEach(activities, id: \.title) { activity in
//                        Button(action: {
//                            selectedActivity = activity
//                        }) {
//                            HStack {
//                                Image(activity.icon)
//                                    .resizable()
//                                    .frame(width: 30, height: 30)
//                                    .background(activity.backgroundColor)
//                                    .clipShape(Circle())
//                                
//                                VStack(alignment: .leading) {
//                                    Text(activity.title)
//                                    Text(activity.subtitle)
//                                        .font(.caption)
//                                        .foregroundColor(.secondary)
//                                }
//                                
//                                Spacer()
//                                
//                                if selectedActivity?.title == activity.title {
//                                    Image(systemName: "checkmark")
//                                        .foregroundColor(.blue)
//                                }
//                            }
//                        }
//                        .buttonStyle(PlainButtonStyle())
//                    }
//                }
//                
//                Section(header: Text("Select Time")) {
//                    DatePicker("Time", selection: $selectedTime, displayedComponents: .hourAndMinute)
//                }
//                
//                Section {
//                    Button("Add to Schedule") {
//                        guard let activity = selectedActivity else { return }
//                        
//                        let scheduleItem = ScheduleItem(
//                            title: activity.title,
//                            subtitle: activity.subtitle,
//                            image: activity.image,
//                            icon: activity.icon,
//                            backgroundColor: activity.backgroundColor,
//                            category: activity.category,
//                            isFavorite: activity.isFavorite,
//                            isParental: activity.isParental,
//                            time: selectedTime
//                        )
//                        
//                        onAdd(scheduleItem)
//                    }
//                    .disabled(selectedActivity == nil)
//                }
//            }
//            .navigationTitle("Add Activity")
//            .toolbar {
//                ToolbarItem(placement: .navigationBarLeading) {
//                    Button("Cancel") {
//                        dismiss()
//                    }
//                }
//            }
//        }
//    }
//}
//
//// MARK: - Preview
//struct ScheduleView_Previews: PreviewProvider {
//    static var previews: some View {
//        ScheduleView()
//    }
//}
