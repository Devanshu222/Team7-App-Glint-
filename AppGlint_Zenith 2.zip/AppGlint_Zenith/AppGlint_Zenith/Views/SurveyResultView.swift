import SwiftUI
import Charts

struct SurveyResultView: View {
    let results: [SurveyResult]
    
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                // Header Section
                VStack(spacing: 10) {
                    Text("Survey Results")
                        .font(.system(size: 28, weight: .bold))
                        .padding(.top, 20)
                    
                    Text("Your child's development progress")
                        .font(.system(size: 16))
                        .foregroundColor(.secondary)
                }
                
                // Overall Score Card
                OverallScoreCard(score: calculateOverallScore())
                    .padding(.horizontal)
                
                // Category Breakdown
                VStack(alignment: .leading, spacing: 15) {
                    Text("Category Breakdown")
                        .font(.system(size: 20, weight: .bold))
                        .padding(.horizontal)
                    
                    ForEach(results) { result in
                        CategoryProgressView(category: result.category, 
                                           score: result.score, 
                                           maxScore: result.maxScore)
                    }
                }
                .padding(.top, 20)
                
                // Detailed Analysis
                VStack(alignment: .leading, spacing: 15) {
                    Text("Detailed Analysis")
                        .font(.system(size: 20, weight: .bold))
                        .padding(.horizontal)
                    
                    if #available(iOS 16.0, *) {
                        Chart {
                            ForEach(results) { result in
                                BarMark(
                                    x: .value("Category", result.category),
                                    y: .value("Score", result.score)
                                )
                                .foregroundStyle(by: .value("Category", result.category))
                            }
                        }
                        .frame(height: 200)
                        .padding()
                    } else {
                        // Fallback for earlier versions
                        VStack {
                            ForEach(results) { result in
                                HStack {
                                    Text(result.category)
                                    Spacer()
                                    Text("\(result.score)/\(result.maxScore)")
                                }
                            }
                        }
                        .padding()
                    }
                }
                .padding(.top, 20)
                
                // Recommendations
                VStack(alignment: .leading, spacing: 15) {
                    Text("Recommendations")
                        .font(.system(size: 20, weight: .bold))
                        .padding(.horizontal)
                    
                    ForEach(getRecommendations(), id: \.self) { recommendation in
                        RecommendationCard(text: recommendation)
                    }
                }
                .padding(.top, 20)
            }
            .padding(.bottom, 40)
        }
        .background(Color(.systemGroupedBackground))
        .navigationTitle("Survey Results")
    }
    
    private func calculateOverallScore() -> Double {
        let totalScore = results.reduce(0) { $0 + $1.score }
        let maxScore = results.reduce(0) { $0 + $1.maxScore }
        return Double(totalScore) / Double(maxScore)
    }
    
    private func getRecommendations() -> [String] {
        // Generate recommendations based on results
        return [
            "Engage in more sensory play activities",
            "Practice calming techniques daily",
            "Increase interactive game time"
        ]
    }
}

// MARK: - Subviews

struct OverallScoreCard: View {
    let score: Double
    
    var body: some View {
        VStack(spacing: 10) {
                    Text("Overall Score")
                        .font(.system(size: 18, weight: .medium))
                        .foregroundColor(.secondary)

            CircularProgresssView(progress: score)
                        .frame(width: 120, height: 120)
                        .padding(.vertical, 10)
            
            Text("\(Int(score * 100))%")
                .font(.system(size: 24, weight: .bold))
        }
        .padding()
        .background(Color(.systemBackground))
        .cornerRadius(15)
        .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 2)
    }
}

struct CircularProgresssView: View {
    let progress: Double
    
    var body: some View {
        ZStack {
            Circle()
                .stroke(lineWidth: 10)
                .opacity(0.3)
                .foregroundColor(.blue)
            
            Circle()
                .trim(from: 0.0, to: CGFloat(min(progress, 1.0)))
                .stroke(style: StrokeStyle(lineWidth: 10, lineCap: .round, lineJoin: .round))
                .foregroundColor(.blue)
                .rotationEffect(Angle(degrees: 270.0))
                .animation(.linear, value: progress)
        }
    }
}

struct CategoryProgressView: View {
    let category: String
    let score: Int
    let maxScore: Int
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text(category)
                    .font(.system(size: 16, weight: .medium))
                
                Spacer()
                
                Text("\(score)/\(maxScore)")
                    .font(.system(size: 16, weight: .bold))
            }
            
            ProgressView(value: Double(score) / Double(maxScore))
                .tint(.blue)
        }
        .padding()
        .background(Color(.systemBackground))
        .cornerRadius(10)
        .padding(.horizontal)
    }
}

struct RecommendationCard: View {
    let text: String
    
    var body: some View {
        HStack {
            Image(systemName: "lightbulb.fill")
                .foregroundColor(.yellow)
                .padding(.trailing, 8)
            
            Text(text)
                .font(.system(size: 14))
                .fixedSize(horizontal: false, vertical: true)
            
            Spacer()
        }
        .padding()
        .background(Color(.systemBackground))
        .cornerRadius(10)
        .padding(.horizontal)
    }
}

// MARK: - Data Models

struct SurveyResult: Identifiable {
    let id = UUID()
    let category: String
    let score: Int
    let maxScore: Int
}

struct SurveyResultView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            SurveyResultView(results: [
                SurveyResult(category: "Sensory", score: 8, maxScore: 10),
                SurveyResult(category: "Calming", score: 6, maxScore: 10),
                SurveyResult(category: "Interactive", score: 7, maxScore: 10)
            ])
        }
    }
} 
