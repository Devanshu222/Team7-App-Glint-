import SwiftUI
import Charts

struct ParentalDashboardView: View {
    @State private var selectedTimeFrame = 0
    @State private var timeFrames = ["D", "W", "Y"]

    var body: some View {
        if #available(iOS 16.0, *) {
            NavigationStack {
                List {
                    Section(header: Text("Progress Tracking")) {
                        NavigationLink(destination: ProgressTrackingDetailView()) {
                            VStack(spacing: 16) {
                                HStack(alignment: .top, spacing: 30) {
                                    VStack(alignment: .leading, spacing: 12) {
                                        ProgressStatView(title: "Sensory", value: "50%", color: .red)
                                        ProgressStatView(title: "Calming", value: "20%", color: .blue)
                                        ProgressStatView(title: "Interactive", value: "30%", color: .green)
                                    }
                                    .frame(width: 100)

                                    LineProgressView()
                                        .frame(maxWidth: .infinity)
                                }
                                .padding(.vertical, 10)
                            }
                        }
                    }

                    Section(header: Text("Structured Learning")) {
                        NavigationLink(destination: ScheduleView()) {
                            Text("Child's Schedule")
                                .font(.system(size: 18))
                        }

                        NavigationLink(destination: PlayedTodayView()) {
                            Text("Played Today")
                                .font(.system(size: 18))
                        }
                    }

                    Section(header: Text("Time Limit")) {
                        TimeLimitView()
                    }
                }
                .listStyle(InsetGroupedListStyle())
                .navigationTitle("Parental Dashboard")
            }
        } else {
            Text("Requires iOS 16 or later")
        }
    }
}

struct ProgressStatView: View {
    let title: String
    let value: String
    let color: Color

    var body: some View {
        VStack(alignment: .leading) {
            Text(title)
                .font(.system(size: 18, weight: .bold))
                .foregroundColor(color)

            Text(value)
                .font(.system(size: 20, weight: .bold))
        }
    }
}

struct LineProgressView: View {
    var body: some View {
        if #available(iOS 16.0, *) {
            Chart {
                ForEach(progressData) { data in
                    LineMark(
                        x: .value("Day", data.day),
                        y: .value("Progress", data.value)
                    )
                    .foregroundStyle(by: .value("Category", data.category))
                }
            }
            .chartXAxis {
                AxisMarks(values: .stride(by: .day)) { value in
                    AxisGridLine()
                    AxisTick()
                    AxisValueLabel(format: .dateTime.day())
                }
            }
            .chartYAxis {
                AxisMarks(position: .leading)
            }
            .frame(height: 200)
        } else {
            VStack {
                Text("Progress Chart")
                    .font(.headline)
            }
            .frame(height: 200)
        }
    }

    private var progressData: [ProgressData] = [
        ProgressData(day: Date().addingTimeInterval(-86400 * 6), value: 20, category: "Sensory"),
        ProgressData(day: Date().addingTimeInterval(-86400 * 5), value: 35, category: "Sensory"),
        ProgressData(day: Date().addingTimeInterval(-86400 * 4), value: 50, category: "Sensory"),
        ProgressData(day: Date().addingTimeInterval(-86400 * 3), value: 40, category: "Calming"),
        ProgressData(day: Date().addingTimeInterval(-86400 * 2), value: 60, category: "Calming"),
        ProgressData(day: Date().addingTimeInterval(-86400 * 1), value: 30, category: "Interactive"),
        ProgressData(day: Date(), value: 50, category: "Interactive")
    ]

    struct ProgressData: Identifiable {
        let id = UUID()
        let day: Date
        let value: Double
        let category: String
    }
}

struct TimeLimitView: View {
    @State private var selectedTime: Date = Date()
    @State private var isTimerRunning = false

    var body: some View {
        HStack {
            DatePicker("", selection: $selectedTime, displayedComponents: .hourAndMinute)
                .datePickerStyle(WheelDatePickerStyle())
                .frame(width: 187)

            Spacer()

            Button(action: {
                isTimerRunning.toggle()
            }) {
                Text(isTimerRunning ? "Stop" : "Start")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundColor(.white)
                    .frame(width: 110, height: 40)
                    .background(isTimerRunning ? Color.red : Color.green)
                    .cornerRadius(8)
            }
        }
        .padding(.vertical, 10)
    }
}

struct ProgressTrackingDetailView: View {
    @State private var selectedTimeFrame = 0

    var body: some View {
        List {
            Section {
                VStack(spacing: 20) {
                    Picker("Time Frame", selection: $selectedTimeFrame) {
                        Text("D").tag(0)
                        Text("W").tag(1)
                        Text("Y").tag(2)
                    }
                    .pickerStyle(SegmentedPickerStyle())
                    .padding(.horizontal)

                    VStack(alignment: .leading, spacing: 8) {
                        Text("Daily Goals")
                            .font(.system(size: 13))
                            .foregroundColor(.gray)

                        HStack {
                            Text("50%")
                                .font(.system(size: 17, weight: .bold))
                            Text("Completed")
                                .foregroundColor(.gray)
                        }

                        Text("Today")
                            .font(.system(size: 13))
                            .foregroundColor(.gray)
                    }
                    .padding(.horizontal)

                    ProgressChartView(timeFrame: selectedTimeFrame)
                }
            }

            Section(header: Text("Highlights")) {
                VStack(alignment: .leading, spacing: 16) {
                    Text("🔥 Tasks")
                        .font(.system(size: 18, weight: .bold))

                    Text("On an average, your tasks this month are about the same as last month.")
                        .font(.system(size: 18, weight: .bold))
                        .fixedSize(horizontal: false, vertical: true)
                }
                .padding(.vertical, 8)

                HStack {
                    Text("5")
                        .font(.system(size: 38, weight: .bold))

                    Text("tasks/day")
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundColor(.gray)

                    Spacer()

                    Text(Date().formatted(.dateTime.month(.wide)))
                        .font(.system(size: 30, weight: .bold))
                }
                .padding(.vertical, 8)
            }
        }
        .listStyle(InsetGroupedListStyle())
        .navigationTitle("Progress Tracking")
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct ProgressChartView: View {
    let timeFrame: Int

    var body: some View {
        if #available(iOS 16.0, *) {
            Chart {
                ForEach(chartData) { data in
                    BarMark(
                        x: .value("Category", data.category),
                        y: .value("Value", data.value)
                    )
                    .foregroundStyle(by: .value("Category", data.category))
                }
            }
            .frame(height: 200)
            .padding()
        } else {
            VStack {
                Text("Progress Chart")
                    .font(.headline)
            }
            .frame(height: 200)
        }
    }

    private var chartData: [ChartData] {
        switch timeFrame {
        case 0: return [ChartData(category: "Sensory", value: 50), ChartData(category: "Calming", value: 20), ChartData(category: "Interactive", value: 30)]
        case 1: return [ChartData(category: "Sensory", value: 35), ChartData(category: "Calming", value: 40), ChartData(category: "Interactive", value: 25)]
        case 2: return [ChartData(category: "Sensory", value: 45), ChartData(category: "Calming", value: 30), ChartData(category: "Interactive", value: 25)]
        default: return []
        }
    }

    struct ChartData: Identifiable {
        let id = UUID()
        let category: String
        let value: Double
    }
}

struct PlayedTodayView: View {
    var body: some View {
        
        Text("Played Today View")
    }
}

struct ScheduleView: View {
    var body: some View {
        Text("Schedule View")
    }
}

struct ParentalDashboardView_Previews: PreviewProvider {
    static var previews: some View {
        ParentalDashboardView()
    }
}
