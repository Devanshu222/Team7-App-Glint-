import SwiftUI

struct AboutUsView: View {
    var body: some View {
        ScrollView {
            VStack(spacing: 30) {
                // Header Section
                VStack(spacing: 20) {
                    Image(systemName: "brain.head.profile") // Replace with your app logo
                        .resizable()
                        .scaledToFit()
                        .frame(width: 100, height: 100)
                        .padding()
                        .background(Color.blue.opacity(0.1))
                        .clipShape(Circle())
                    
                    Text("About AppGlint Zenith")
                        .font(.system(size: 28, weight: .bold))
                    
                    Text("Let's talk, let's play, let's learn!")
                        .font(.system(size: 18, weight: .medium))
                        .foregroundColor(.secondary)
                }
                .padding(.top, 40)
                
                // Mission Section
                VStack(alignment: .leading, spacing: 15) {
                    SectionHeader(title: "Our Mission")
                    
                    Text("At AppGlint Zenith, we're dedicated to helping parents create a balanced and enriching environment for their children's growth and development.")
                        .font(.system(size: 16))
                        .lineSpacing(5)
                    
                    FeatureCard(icon: "hand.raised.fill", 
                               title: "Parental Control",
                               description: "Manage screen time and activities effectively")
                    
                    FeatureCard(icon: "chart.bar.fill", 
                               title: "Progress Tracking",
                               description: "Monitor your child's development milestones")
                    
                    FeatureCard(icon: "calendar", 
                               title: "Structured Learning",
                               description: "Create and manage daily schedules")
                }
                .padding(.horizontal)
                
                // Team Section
//                VStack(alignment: .leading, spacing: 15) {
//                    SectionHeader(title: "Our Team")
//                    
//                    HStack(spacing: 20) {
//                        TeamMemberCard(name: "Devanshu Singh", 
//                                     role: "Lead Developer",
//                                     image: "devanshu") // Replace with actual image
//                        
//                        TeamMemberCard(name: "John Doe", 
//                                     role: "UI/UX Designer",
//                                     image: "john") // Replace with actual image
//                    }
//                }
//                .padding(.horizontal)
                
                // Contact Section
                VStack(alignment: .leading, spacing: 15) {
                    SectionHeader(title: "Contact Us")
                    
                    ContactButton(icon: "envelope.fill", 
                                text: "support@appglint.com",
                                action: {
                        // Handle email action
                    })
                    
                    ContactButton(icon: "phone.fill", 
                                text: "+1 (234) 567-890",
                                action: {
                        // Handle phone action
                    })
                }
                .padding(.horizontal)
                .padding(.bottom, 40)
            }
        }
        .navigationTitle("About Us")
    }
}

// MARK: - Subviews

struct SectionHeader: View {
    let title: String
    
    var body: some View {
        Text(title)
            .font(.system(size: 22, weight: .bold))
            .padding(.vertical, 5)
    }
}

struct FeatureCard: View {
    let icon: String
    let title: String
    let description: String
    
    var body: some View {
        HStack(spacing: 15) {
            Image(systemName: icon)
                .font(.title2)
                .foregroundColor(.blue)
                .frame(width: 40)
            
            VStack(alignment: .leading, spacing: 5) {
                Text(title)
                    .font(.system(size: 18, weight: .medium))
                
                Text(description)
                    .font(.system(size: 14))
                    .foregroundColor(.secondary)
            }
        }
        .padding()
        .background(Color(.systemBackground))
        .cornerRadius(10)
        .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 2)
    }
}

//struct TeamMemberCard: View {
//    let name: String
//    let role: String
//    let image: String
//    
//    var body: some View {
//        VStack(spacing: 10) {
//            Image(image)
//                .resizable()
//                .scaledToFill()
//                .frame(width: 100, height: 100)
//                .clipShape(Circle())
//                .overlay(Circle().stroke(Color.blue, lineWidth: 2))
//            
//            Text(name)
//                .font(.system(size: 16, weight: .medium))
//            
//            Text(role)
//                .font(.system(size: 14))
//                .foregroundColor(.secondary)
//        }
//    }
//}

struct ContactButton: View {
    let icon: String
    let text: String
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            HStack(spacing: 15) {
                Image(systemName: icon)
                    .font(.title2)
                    .foregroundColor(.blue)
                
                Text(text)
                    .font(.system(size: 16))
                    .foregroundColor(.primary)
                
                Spacer()
                
                Image(systemName: "chevron.right")
                    .foregroundColor(.secondary)
            }
            .padding()
            .background(Color(.systemBackground))
            .cornerRadius(10)
            .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 2)
        }
    }
}

struct AboutUsView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            AboutUsView()
        }
    }
} 
