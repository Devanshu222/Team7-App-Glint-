import UIKit

class GameCell: UICollectionViewCell {
    static let identifier = "GameCell"
    
    private let containerView: UIView = {
        let view = UIView()
        view.layer.cornerRadius = 24
        view.clipsToBounds = true
        return view
    }()
//    
    private let titleLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 42, weight: .bold)
        label.textColor = .white
        label.numberOfLines = 2
        return label
    }()
//    
    private let iconView: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        imageView.tintColor = .white
        return imageView
    }()
//    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupViews()
        
        layer.shadowColor = UIColor.black.cgColor
        layer.shadowOffset = CGSize(width: 0, height: 4)
        layer.shadowRadius = 12
        layer.shadowOpacity = 0.1
        layer.masksToBounds = false
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(cellTapped))
        addGestureRecognizer(tapGesture)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupViews() {
        contentView.addSubview(containerView)
        containerView.addSubview(titleLabel)
        containerView.addSubview(iconView)
        
        containerView.translatesAutoresizingMaskIntoConstraints = false
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        iconView.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            containerView.topAnchor.constraint(equalTo: contentView.topAnchor),
            containerView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            containerView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
            containerView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor),
            
            titleLabel.leadingAnchor.constraint(equalTo: containerView.leadingAnchor, constant: 24),
            titleLabel.bottomAnchor.constraint(equalTo: containerView.bottomAnchor, constant: -24),
            titleLabel.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: -80),
            
            iconView.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: -24),
            iconView.bottomAnchor.constraint(equalTo: containerView.bottomAnchor, constant: -24),
            iconView.widthAnchor.constraint(equalToConstant: 48),
            iconView.heightAnchor.constraint(equalToConstant: 48)
        ])
    }
    
    func configure(with game: Games) {
        containerView.backgroundColor = game.backgroundColor
        titleLabel.text = game.title
        iconView.image = game.icon
    }
    func configureRecent(with index: Int) {
        guard let game = UserDataManager.shared.getRecentGame(at: index) else {
            print("Error: No game found at index \(index)")
            return
        }

        containerView.backgroundColor = game.backgroundColor
        titleLabel.text = game.title
        iconView.image = game.icon
    }
    private func findParentViewController() -> UIViewController? {
        var responder: UIResponder? = self
        while let nextResponder = responder?.next {
            if let viewController = nextResponder as? UIViewController {
                return viewController
            }
            responder = nextResponder
        }
        return nil
    }
    @objc private func cellTapped() {
            guard let parentViewController = findParentViewController() else { return }

            let storyboard = UIStoryboard(name: "Bubble", bundle: nil)
            if let bubbleVC = storyboard.instantiateViewController(withIdentifier: "BubbleViewController") as? BubbleViewController {
                bubbleVC.isFavourite = false
                bubbleVC.Gametitle = "Game"
                parentViewController.present(bubbleVC, animated: true, completion: nil)
            }
        }

}
//
//import UIKit
//
//
//
//
//
//
//// 1. First, modify your GameCell class to store the game data
//class GameCell: UICollectionViewCell {
//    static let identifier = "GameCell"
//    
//    // Add a property to store the current game
//    private var currentGame: Games?
//    
//    private let containerView: UIView = {
//        let view = UIView()
//        view.layer.cornerRadius = 24
//        view.clipsToBounds = true
//        return view
//    }()
//    
//    private let titleLabel: UILabel = {
//        let label = UILabel()
//        label.font = .systemFont(ofSize: 42, weight: .bold)
//        label.textColor = .white
//        label.numberOfLines = 2
//        return label
//    }()
//    
//    private let iconView: UIImageView = {
//        let imageView = UIImageView()
//        imageView.contentMode = .scaleAspectFit
//        imageView.tintColor = .white
//        return imageView
//    }()
//    
//    override init(frame: CGRect) {
//        super.init(frame: frame)
//        setupViews()
//        
//        layer.shadowColor = UIColor.black.cgColor
//        layer.shadowOffset = CGSize(width: 0, height: 4)
//        layer.shadowRadius = 12
//        layer.shadowOpacity = 0.1
//        layer.masksToBounds = false
//        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(cellTapped))
//        addGestureRecognizer(tapGesture)
//    }
//    
//    required init?(coder: NSCoder) {
//        fatalError("init(coder:) has not been implemented")
//    }
//    
//    private func setupViews() {
//        contentView.addSubview(containerView)
//        containerView.addSubview(titleLabel)
//        containerView.addSubview(iconView)
//        
//        containerView.translatesAutoresizingMaskIntoConstraints = false
//        titleLabel.translatesAutoresizingMaskIntoConstraints = false
//        iconView.translatesAutoresizingMaskIntoConstraints = false
//        
//        NSLayoutConstraint.activate([
//            containerView.topAnchor.constraint(equalTo: contentView.topAnchor),
//            containerView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
//            containerView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
//            containerView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor),
//            
//            titleLabel.leadingAnchor.constraint(equalTo: containerView.leadingAnchor, constant: 24),
//            titleLabel.bottomAnchor.constraint(equalTo: containerView.bottomAnchor, constant: -24),
//            titleLabel.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: -80),
//            
//            iconView.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: -24),
//            iconView.bottomAnchor.constraint(equalTo: containerView.bottomAnchor, constant: -24),
//            iconView.widthAnchor.constraint(equalToConstant: 48),
//            iconView.heightAnchor.constraint(equalToConstant: 48)
//        ])
//    }
//    
//    // Update the configure method to store the game
//    func configure(with game: Games) {
//        currentGame = game
//        containerView.backgroundColor = game.backgroundColor
//        titleLabel.text = game.title
//        iconView.image = game.icon
//    }
//    
//    func configureRecent(with index: Int) {
//        guard let game = UserDataManager.shared.getRecentGame(at: index) else {
//            print("Error: No game found at index \(index)")
//            return
//        }
//        
//        currentGame = game
//        containerView.backgroundColor = game.backgroundColor
//        titleLabel.text = game.title
//        iconView.image = game.icon
//    }
//    
//    // Add the missing findParentViewController method
//    private func findParentViewController() -> UIViewController? {
//        var responder: UIResponder? = self
//        while let nextResponder = responder?.next {
//            if let viewController = nextResponder as? UIViewController {
//                return viewController
//            }
//            responder = nextResponder
//        }
//        return nil
//    }
//    
//    @objc private func cellTapped() {
//        guard let parentViewController = findParentViewController() else { return }
//        
//        // Create the highlight effect first
//        animateHighlight {
//            // Then present the detail view
//            self.presentGameDetailView(from: parentViewController)
//        }
//    }
//    
//    private func animateHighlight(completion: @escaping () -> Void) {
//        // Create a snapshot of the cell for the animation
//        guard let snapshotView = self.snapshotView(afterScreenUpdates: false) else {
//            completion()
//            return
//        }
//        
//        guard let parentView = self.superview?.superview else {
//            completion()
//            return
//        }
//        
//        // Get the frame in the parent view's coordinate system
//        let frameInParent = self.convert(self.bounds, to: parentView)
//        snapshotView.frame = frameInParent
//        
//        // Add highlight effect
//        let highlightOverlay = UIView(frame: snapshotView.bounds)
//        highlightOverlay.backgroundColor = UIColor.white.withAlphaComponent(0.3)
//        highlightOverlay.layer.cornerRadius = 24
//        snapshotView.addSubview(highlightOverlay)
//        
//        // Add to parent view and animate
//        parentView.addSubview(snapshotView)
//        
//        UIView.animate(withDuration: 0.15, animations: {
//            snapshotView.transform = CGAffineTransform(scaleX: 1.05, y: 1.05)
//            snapshotView.layer.shadowColor = UIColor.black.cgColor
//            snapshotView.layer.shadowOpacity = 0.2
//            snapshotView.layer.shadowOffset = CGSize(width: 0, height: 8)
//            snapshotView.layer.shadowRadius = 16
//        }) { _ in
//            UIView.animate(withDuration: 0.1, animations: {
//                snapshotView.transform = .identity
//            }) { _ in
//                snapshotView.removeFromSuperview()
//                completion()
//            }
//        }
//    }
//    
//    private func presentGameDetailView(from viewController: UIViewController) {
//        let storyboard = UIStoryboard(name: "Bubble", bundle: nil)
//        if let bubbleVC = storyboard.instantiateViewController(withIdentifier: "BubbleViewController") as? BubbleViewController {
//            bubbleVC.isFavourite = false
//            // Pass the current game data
//            if let game = currentGame {
//                // Fixed: Don't try to set properties that don't exist
//                bubbleVC.Gametitle = game.title
//                
//                // Instead of trying to set properties directly, we'll update the UI in viewDidLoad
//                if let navController = bubbleVC.navigationController {
//                    navController.modalPresentationStyle = .custom
//                    navController.modalTransitionStyle = .coverVertical
//                    viewController.present(navController, animated: true)
//                } else {
//                    bubbleVC.modalPresentationStyle = .custom
//                    bubbleVC.modalTransitionStyle = .coverVertical
//                    viewController.present(bubbleVC, animated: true)
//                }
//            }
//        }
//    }
//}
//// 2. Now, modify the BubbleViewController to receive and display the game data
//
////class BubbleViewController: UIViewController {
////    var isFavourite: Bool = false
////    var Gametitle: String = ""
////    var gameData: Games?
////    var gameIcon: UIImage?
////    var gameColor: UIColor?
////    
////    @IBOutlet weak var gameImageView: UIImageView!
////    @IBOutlet weak var gameTitleLabel: UILabel!
////    @IBOutlet weak var gameDescriptionLabel: UILabel!
////    @IBOutlet weak var headerView: UIView!
////    
////    override func viewDidLoad() {
////        super.viewDidLoad()
////        
////        setupUI()
////        configureWithGameData()
////    }
////    
////    private func setupUI() {
////        // Set up basic UI elements
////        view.layer.cornerRadius = 24
////        view.clipsToBounds = true
////        
////        // Apply corner radius to header view
////        headerView.layer.cornerRadius = 24
////        headerView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
////        
////        // Add a handle for intuitive pull-down to dismiss
////        let handleView = UIView()
////        handleView.backgroundColor = UIColor.gray.withAlphaComponent(0.5)
////        handleView.layer.cornerRadius = 2.5
////        handleView.translatesAutoresizingMaskIntoConstraints = false
////        view.addSubview(handleView)
////        
////        NSLayoutConstraint.activate([
////            handleView.topAnchor.constraint(equalTo: view.topAnchor, constant: 12),
////            handleView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
////            handleView.widthAnchor.constraint(equalToConstant: 40),
////            handleView.heightAnchor.constraint(equalToConstant: 5)
////        ])
////        
////        // Add pull-down gesture to dismiss
////        let panGesture = UIPanGestureRecognizer(target: self, action: #selector(handlePanGesture(_:)))
////        view.addGestureRecognizer(panGesture)
////    }
////    
////    private func configureWithGameData() {
////        // Set the game title
////        gameTitleLabel.text = Gametitle
////        
////        // Set the game icon/image if available
////        if let icon = gameIcon {
////            gameImageView.image = icon
////            gameImageView.contentMode = .scaleAspectFit
////            gameImageView.tintColor = .white
////        }
////        
////        // Set the header background color
////        if let color = gameColor {
////            headerView.backgroundColor = color
////        }
////        
////        // Set the game description if available
////        if let game = gameData {
////            // Assuming Games has a description property
////            if let description = game.description {
////                gameDescriptionLabel.text = description
////            } else {
////                gameDescriptionLabel.text = "No description available for this game."
////            }
////            
////            // Add to recent games
////            UserDataManager.shared.addRecentGame(game)
////        }
////    }
////    
////    @objc private func handlePanGesture(_ gesture: UIPanGestureRecognizer) {
////        let translation = gesture.translation(in: view)
////        let velocity = gesture.velocity(in: view)
////        
////        switch gesture.state {
////        case .changed:
////            // Only allow downward dragging
////            if translation.y > 0 {
////                view.transform = CGAffineTransform(translationX: 0, y: translation.y)
////            }
////        case .ended:
////            if translation.y > 100 || velocity.y > 500 {
////                // Dismiss if dragged far enough or with enough velocity
////                dismiss(animated: true, completion: nil)
////            } else {
////                // Otherwise, return to original position
////                UIView.animate(withDuration: 0.3) {
////                    self.view.transform = .identity
////                }
////            }
////        default:
////            break
////        }
////    }
////}
