import UIKit

protocol PickerViewControllerDelegate: AnyObject {
    func didAddScheduleItem(_ item: ScheduleItem)
}

class PickerViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {

    weak var delegate: PickerViewControllerDelegate?

    private let scheduleItems: [Activites] = UserDataManager.shared.getAllGames()
    private var selectedActivity: Activites?
    private var selectedTime = Date()

    private let gamePicker = UIPickerView()
    private let timePicker = UIDatePicker()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.systemBackground
        setupUI()
        selectedActivity = scheduleItems.first
    }

    private func setupUI() {
        // Heading Label
        let headingLabel = UILabel()
        headingLabel.text = "Select an Activity and Time"
        headingLabel.font = UIFont.boldSystemFont(ofSize: 24)
        headingLabel.textAlignment = .center
        headingLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(headingLabel)

        // Game Picker
        gamePicker.delegate = self
        gamePicker.dataSource = self
        gamePicker.translatesAutoresizingMaskIntoConstraints = false
        gamePicker.layer.cornerRadius = 12
        gamePicker.clipsToBounds = true
        view.addSubview(gamePicker)

        // Time Picker
        timePicker.datePickerMode = .time
        timePicker.preferredDatePickerStyle = .wheels
        timePicker.translatesAutoresizingMaskIntoConstraints = false
        timePicker.backgroundColor = UIColor.secondarySystemBackground
        timePicker.layer.cornerRadius = 12
        timePicker.clipsToBounds = true
        view.addSubview(timePicker)

        // Button Stack
        let buttonStack = UIStackView()
        buttonStack.axis = .horizontal
        buttonStack.distribution = .fillEqually
        buttonStack.spacing = 16
        buttonStack.translatesAutoresizingMaskIntoConstraints = false

        let cancelButton = createStyledButton(title: "Cancel", action: #selector(cancelTapped))
        let saveButton = createStyledButton(title: "Save", action: #selector(saveTapped))

        buttonStack.addArrangedSubview(cancelButton)
        buttonStack.addArrangedSubview(saveButton)

        view.addSubview(buttonStack)

        // Layout Constraints
        NSLayoutConstraint.activate([
            headingLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            headingLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            headingLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),

            gamePicker.topAnchor.constraint(equalTo: headingLabel.bottomAnchor, constant: 20),
            gamePicker.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            gamePicker.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),

            timePicker.topAnchor.constraint(equalTo: gamePicker.bottomAnchor, constant: 30),
            timePicker.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            timePicker.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),

            buttonStack.topAnchor.constraint(equalTo: timePicker.bottomAnchor, constant: 40),
            buttonStack.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            buttonStack.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            buttonStack.heightAnchor.constraint(equalToConstant: 50)
        ])
    }

    private func createStyledButton(title: String, action: Selector) -> UIButton {
        let button = UIButton(type: .system)
        button.setTitle(title, for: .normal)
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 18)
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = title == "Save" ? UIColor.systemBlue : UIColor.systemGray
        button.layer.cornerRadius = 12
        button.addTarget(self, action: action, for: .touchUpInside)
        return button
    }

    @objc private func cancelTapped() {
        dismiss(animated: true)
    }

    @objc private func saveTapped() {
        guard let selectedActivity = selectedActivity else { return }

        let calendar = Calendar.current
        let now = Date()
        let components = calendar.dateComponents([.hour, .minute], from: timePicker.date)

        if let scheduleTime = calendar.date(bySettingHour: components.hour ?? 0,
                                            minute: components.minute ?? 0,
                                            second: 0,
                                            of: now) {
            let newItem = ScheduleItem(
                title: selectedActivity.title,
                subtitle: selectedActivity.subtitle,
                image: selectedActivity.image,
                icon: selectedActivity.icon,
                backgroundColor: selectedActivity.backgroundColor,
                category: selectedActivity.category,
                isFavourite: selectedActivity.isFavourite,
                isParental: selectedActivity.isParental,
                time: scheduleTime
            )
            delegate?.didAddScheduleItem(newItem)
        }
        dismiss(animated: true)
    }

    // MARK: - UIPickerView DataSource & Delegate
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }

    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return scheduleItems.count
    }

    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return scheduleItems[row].title
    }

    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        selectedActivity = scheduleItems[row]
    }
}
