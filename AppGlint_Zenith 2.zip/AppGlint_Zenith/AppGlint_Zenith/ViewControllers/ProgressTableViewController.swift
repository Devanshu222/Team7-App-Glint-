//
//  ProgressTableViewController.swift
//  GlintParental
//
//  Created by student-2 on 16/01/25.
//
import Foundation
import UIKit
import SwiftUI

//class WeeklyProgressChartView: UIView {
//
//    struct CategoryData {
//        let category: String
//        let color: UIColor
//        let values: [CGFloat] // Values for each day (Thu-Wed)
//    }
//
//    let chartData: [CategoryData] = [
//        CategoryData(category: "Sensory", color: .red, values: [30, 15, 10, 0, 35, 0, 10]),
//        CategoryData(category: "Calming", color: .green, values: [0, 20, 5, 15, 0, 30, 0]),
//        CategoryData(category: "Interactive", color: .cyan, values: [0, 0, 0, 0, 0, 0, 0]) // Sample
//    ]
//
//    let daysOfWeek = ["Thu", "Fri", "Sat", "Sun", "Mon", "Tue", "Wed"]
//    let maxValue: CGFloat = 40 // Based on your image
//
//    override init(frame: CGRect) {
//        super.init(frame: frame)
//        backgroundColor = .white
//    }
//
//    required init?(coder: NSCoder) {
//        super.init(coder: coder)
//        backgroundColor = .white
//    }
//
//    override func draw(_ rect: CGRect) {
//        guard let context = UIGraphicsGetCurrentContext() else { return }
//
//        let chartWidth = rect.width * 0.8
//        let chartHeight = rect.height * 0.6
//        let startX = rect.width * 0.15
//        let startY = rect.height * 0.75 // Adjust for labels and title
//
//        // Draw Y-axis and labels
//        context.setStrokeColor(UIColor.lightGray.cgColor)
//        context.setLineWidth(1)
//        context.move(to: CGPoint(x: startX, y: startY - chartHeight))
//        context.addLine(to: CGPoint(x: startX, y: startY))
//        context.strokePath()
//
//        let yAxisLabelCount = 5
//        for i in 0..<yAxisLabelCount {
//            let value = maxValue * CGFloat(yAxisLabelCount - 1 - i) / CGFloat(yAxisLabelCount - 1)
//            let yPos = startY - chartHeight * CGFloat(i) / CGFloat(yAxisLabelCount - 1)
//            drawText("\(Int(value))", at: CGPoint(x: startX - 20, y: yPos - 8), font: UIFont.systemFont(ofSize: 10), color: .lightGray)
//            context.move(to: CGPoint(x: startX - 5, y: yPos))
//            context.addLine(to: CGPoint(x: startX, y: yPos))
//            context.strokePath()
//        }
//
//        // Draw X-axis and labels
//        context.move(to: CGPoint(x: startX, y: startY))
//        context.addLine(to: CGPoint(x: startX + chartWidth, y: startY))
//        context.strokePath()
//
//        let barSpacing: CGFloat = 10
//        let barsPerDay = CGFloat(chartData.count)
//        let availableWidthPerDay = (chartWidth - (CGFloat(daysOfWeek.count) + 1) * barSpacing) / CGFloat(daysOfWeek.count)
//        let barWidth = availableWidthPerDay / barsPerDay
//
//        for (dayIndex, day) in daysOfWeek.enumerated() {
//            let dayStartX = startX + barSpacing + CGFloat(dayIndex) * (availableWidthPerDay + barSpacing)
//            drawText(day, at: CGPoint(x: dayStartX + availableWidthPerDay / 2 - 10, y: startY + 5), font: UIFont.systemFont(ofSize: 10), color: .gray)
//
//            for (categoryIndex, data) in chartData.enumerated() {
//                let barValue = data.values[dayIndex]
//                let barHeight = chartHeight * (barValue / maxValue)
//                let barX = dayStartX + CGFloat(categoryIndex) * barWidth
//                let barY = startY - barHeight
//
//                context.setFillColor(data.color.cgColor)
//                context.addRect(CGRect(x: barX, y: barY, width: barWidth, height: barHeight))
//                context.fillPath()
//            }
//        }
//
//        // Draw Title and Legend
//        drawText("Weekly Goals", at: CGPoint(x: startX, y: rect.height * 0.1), font: UIFont.boldSystemFont(ofSize: 16), color: .black)
//        drawText("50% Completed", at: CGPoint(x: startX, y: rect.height * 0.1 + 20), font: UIFont.systemFont(ofSize: 14), color: .gray) // Adjust
//
//        var legendX = startX
//        let legendY = rect.height * 0.25
//        let legendSquareSize: CGFloat = 10
//        let legendSpacing: CGFloat = 8
//
//        for data in chartData {
//            context.setFillColor(data.color.cgColor)
//            context.addRect(CGRect(x: legendX, y: legendY, width: legendSquareSize, height: legendSquareSize))
//            context.fillPath()
//            drawText(data.category, at: CGPoint(x: legendX + legendSquareSize + legendSpacing, y: legendY - 2), font: UIFont.systemFont(ofSize: 12), color: .gray)
//            legendX += 100 // Adjust spacing as needed
//        }
//    }
//
//    private func drawText(_ text: String, at point: CGPoint, font: UIFont, color: UIColor) {
//        let attributes = [NSAttributedString.Key.font: font, NSAttributedString.Key.foregroundColor: color]
//        let attributedText = NSAttributedString(string: text, attributes: attributes)
//        attributedText.draw(at: point)
//    }
//}
//
//let chartView = WeeklyProgressChartView(frame: CGRect(x: 20, y: 100, width: 300, height: 250)) // Adjust frame
//View.addSubview(chartView)


class ProgressTableViewController: UITableViewController {

    @IBOutlet weak var segmentedControl: UISegmentedControl!
    @IBOutlet weak var UIViewTapped: UIView!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

//         Uncomment the following line to preserve selection between presentations
         self.clearsSelectionOnViewWillAppear = false

//         Uncomment the following line to display an Edit button in the navigation bar for this view controller.
//         self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    // MARK: - Table view data source

//    @IBOutlet weak var View: UIView!
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 2
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        if(section == 0) {
            return 1
        }
        else {
            return 2
        }
        return 0
    }

    /*
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)

        // Configure the cell...

        return cell
    }
    */

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    
    
    
//    @IBAction func segmentedControlValueChanged(_ sender: UISegmentedControl) {
//        if sender.selectedSegmentIndex == 0{
//            print("0 selected")
//            UIViewTapped.isHidden = false
//        }else {  UIViewTapped.isHidden = true}
//    }

}
