//
//  ResultViewController.swift
//  AppGlint_Zenith
//
//  Created by Devanshu Singh(chitkara)     on 12/12/24.
//

import UIKit

class ResultViewController: UIViewController {
    @IBOutlet weak var resultTextView: UITextView!
    
//    @IBOutlet weak var gamesCollectionView: UICollectionView!
        
        struct SurveyAnswer {
            let questionId: Int
            let selectedOption: Int?
            let isTrue: Bool?  // Ensure these properties are optional
            let answerText: String?
        }
        
        var surveyAnswers: [SurveyAnswer] = []
        var recommendedGames: [Games] = []
        
        override func viewDidLoad() { 
            super.viewDidLoad()
            //setupCollectionView()
            
            Task {
                    await displayResults()
                }
        }
        
//        private func setupCollectionView() {
//            gamesCollectionView.delegate = self
//            gamesCollectionView.dataSource = self
//            gamesCollectionView.register(GameCell.self, forCellWithReuseIdentifier: GameCell.identifier)
//        }
    private func displayResults() async {
        let scores = await calculateCategoryScores()
            resultTextView.text = scores
        var category: String?
        var insight: String?

        let lines = scores!.components(separatedBy: "\n")
        for line in lines {
            if line.starts(with: "Category:") {
                category = line.replacingOccurrences(of: "Category: ", with: "")
            } else if line.starts(with: "Insight:") {
                insight = line.replacingOccurrences(of: "Insight: ", with: "")
            }
        }
        print(category!)
        print(insight!)
            //recommendedGames = getRecommendedGames(for: scores)
            //gamesCollectionView.reloadData()
        }
        
//        private func calculateCategoryScores() -> (calming: Int, interactive: Int, social: Int, sensory: Int) {  
//            var scores = (calming: 0, interactive: 0, social: 0, sensory: 0)
//            for answer in surveyAnswers {
//                let question = AutismSurveyManager.questions[answer.questionId]
//                if answer.selectedOption == question.correctAnswerIndex {
//                    switch question.category {
//                    case .calming: scores.calming += 1
//                    case .interactive: scores.interactive += 1
//                    //case .social: scores.social += 1
//                    case .sensory: scores.sensory += 1
//                    }
//                }
//            }
//            return scores
//        }
    private func calculateCategoryScores() async -> String? {
        let apiKey = "AIzaSyA6dW4BEFOlI2hPCrXIKnKlZVP2GhRLAdU"  // Replace with your actual API key
        let endpoint = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=\(apiKey)"

        // Mapping function for selectedOption
        func optionToText(_ option: Int) -> String {
            switch option {
            case 0: return "Yes"
            case 1: return "Sometimes"
            case 2: return "No"
            default: return "Unknown"  // Handle unexpected values
            }
        }

        // Convert survey answers into JSON format with mapped values
        let answersData = surveyAnswers.map { answer in
            return [
                "questionId": AutismSurveyManager.questions[answer.questionId],
                "selectedOption": optionToText(answer.selectedOption!) // Map int to text
            ]
        }

        let requestBody: [String: Any] = [
                "contents": [
                    [
                        "parts": [
                            [
                                "text": """
                                Analyze the following survey responses and determine the most relevant category for the child:

                                - If the first 5 questions have more "Yes" responses, categorize the child as **Calming**.  
                                - If the middle 5 questions have more "Yes" responses, categorize as **Interactive**.  
                                - If the last 5 questions have more "Yes" responses, categorize as **Sensory**.  
                                - Otherwise, if responses are mixed or unclear, make the best possible guess.  

                                Additionally, provide a short insight as **information for the parent** about their child’s tendencies, strengths, and how they might support them.
                                
                                Do NOT give anything else besides the given format
                                
                                Example Response Format:
                                ```
                                Category: Interactive
                                Insight: The child shows engagement in activities, prefers interactive elements, and enjoys social interactions.
                                ```

                                Responses: \(answersData)
                                """
                            ]
                        ]
                    ]
                ]
            ]

        guard let jsonData = try? JSONSerialization.data(withJSONObject: requestBody, options: .prettyPrinted) else {
            print("❌ Failed to encode JSON")
            return nil
        }

        // Print JSON request body
        if let jsonString = String(data: jsonData, encoding: .utf8) {
            print("📤 JSON Request Body:\n\(jsonString)")
        }

        // Create URL Request
        var request = URLRequest(url: URL(string: endpoint)!)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = jsonData

        do {
            let (data, response) = try await URLSession.shared.data(for: request)
            
            // Print HTTP response details
            if let httpResponse = response as? HTTPURLResponse {
                print("📩 HTTP Response Status Code: \(httpResponse.statusCode)")
            }
            
            // Print Raw Response Data
            if let rawResponse = String(data: data, encoding: .utf8) {
                print("📩 Raw API Response:\n\(rawResponse)")
            }

            if let jsonResponse = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
                print("📩 Parsed JSON Response: \(jsonResponse)")
                
                if let candidates = jsonResponse["candidates"] as? [[String: Any]],
                   let output = candidates.first?["content"] as? [String: Any],
                   let parts = output["parts"] as? [[String: Any]],
                   let category = parts.first?["text"] as? String {
                    print("✅ Extracted Category: \(category)")
                    return category.trimmingCharacters(in: .whitespacesAndNewlines)
                } else {
                    print("⚠️ Unable to extract category from response")
                }
            } else {
                print("❌ Failed to parse JSON response")
            }
        } catch {
            print("❌ Error making API request: \(error)")
        }

        return nil
    }



    
        
    private func generateResultText(for scores: (calming: Int, interactive: Int, social: Int, sensory: Int)) -> String {
        var text = "Your child's profile:\n\n"
        
        if scores.calming >= 5 {
            text += "Calming activities recommended.\n"
        } else {
            text += "Your child may not require extensive calming activities, but occasional relaxation exercises could be beneficial.\n"
        }
        
        if scores.interactive >= 5 {
            text += "Interactive experiences recommended.\n"
        } else {
            text += "Limited need for interactive experiences, but structured engagement might help.\n"
        }
        
        if scores.social >= 5 {
            text += "Social skill support recommended.\n"
        } else {
            text += "Social skills appear balanced, but occasional peer interactions could be helpful.\n"
        }
        
        if scores.sensory >= 5 {
            text += "Sensory-friendly environment recommended.\n"
        } else {
            text += "Your child may not require a sensory-friendly setup, but some sensory considerations might still be useful.\n"
        }
        
        // Determine the dominant category
        let categories = [
            "Calming": scores.calming,
            "Interactive": scores.interactive,
            //"Social": scores.social,
            "Sensory": scores.sensory
        ]
        
        let category = categories.max { $0.value < $1.value }?.key ?? "None"
        UserDataManager.shared.saveAutismCategory(category)
        return text + "\nDominant Category: \(category)"
    }


        
        private func getRecommendedGames(for scores: (calming: Int, interactive: Int, social: Int, sensory: Int)) -> [Games] {
            var recommended = [Games]()
            if scores.calming > 5 { recommended.append(contentsOf: games.filter { $0.title.contains("Bubble") }) }
            if scores.interactive > 5 { recommended.append(contentsOf: games.filter { $0.title.contains("Chat") }) }
            if scores.social > 5 { recommended.append(contentsOf: games.filter { $0.title.contains("Trivia") }) }
            if scores.sensory > 5 { recommended.append(contentsOf: games.filter { $0.title.contains("Puzzle") }) }
            return recommended
        }
    }

    extension ResultViewController: UICollectionViewDelegate, UICollectionViewDataSource {
        func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
            return recommendedGames.count
        }
        
        func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: GameCell.identifier, for: indexPath) as! GameCell
            cell.configure(with: recommendedGames[indexPath.item])
            return cell
        }
        @IBAction func DoneButtonTapped(_ sender: Any) {
               let storyboard = UIStoryboard(name: "Home", bundle: nil)
                       let HomeTBC = storyboard.instantiateViewController(withIdentifier: "tabBarVC") as! UITabBarController

//                       let categoryScores = calculateCategoryScores()
//                       UserDefaults.standard.set(categoryScores.calming, forKey: "calmingScore")
//                       UserDefaults.standard.set(categoryScores.interactive, forKey: "interactiveScore")
//                       UserDefaults.standard.set(categoryScores.social, forKey: "socialScore")
//                       UserDefaults.standard.set(categoryScores.sensory, forKey: "sensoryScore")

                       HomeTBC.modalPresentationStyle = .fullScreen
                       present(HomeTBC, animated: true)
           }
    }


