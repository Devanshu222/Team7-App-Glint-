//
//  LoginScreenViewController.swift
//  AppGlint_Zenith
//
//  Created by Devanshu Singh(chitkara)     on 04/12/24.
//

import UIKit
import Supabase
class LoginScreenViewController: UIViewController {

    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var myView: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        //myView
        //let myView = UIView(frame: CGRect(x: 100, y: 100, width: 200, height: 200))
               myView.backgroundColor = .white

               // Add an outline
               myView.layer.borderWidth = 2.0
               myView.layer.borderColor = UIColor.black.cgColor

               // Add rounded corners and shadow
               myView.layer.cornerRadius = 10.0
               myView.layer.shadowColor = UIColor.gray.cgColor
               myView.layer.shadowOpacity = 0.5
               myView.layer.shadowOffset = CGSize(width: 2, height: 2)

               // Add the view to the view controller's view
            //view.addSubview(myView)
        // Do any additional setup after loading the view.
    
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func LoginButtonTapped(_ sender: Any) {
        
//        let storyboard = UIStoryboard(name: "Home", bundle: nil)
//        let HomeTBC = storyboard.instantiateViewController(withIdentifier: "tabBarVC") as! UITabBarController
//        HomeTBC.modalPresentationStyle = .fullScreen
////        performSegue(withIdentifier: "Survey", sender: self)
//        present(HomeTBC.self , animated: true)
        guard let email = email.text, !email.isEmpty else {
                    showAlert(message: "Please enter an email.")
                    return
                }

                checkEmailInDatabase(email: email)
    }
    func checkEmailInDatabase(email: String) {
            Task {
                do {
                    let response = try await SupabaseAPIClient.shared.supabase
                        .from("users")
                        .select("parentEmail")
                        .eq("parentEmail", value: email)
                        .execute()
                    
                    // Decode the JSON response
                    let data = try JSONDecoder().decode([[String: String]].self, from: response.data)

                    if !data.isEmpty {
                        navigateToHome()
                    } else {
                        showAlert(message: "Email not found. Please sign up.")
                    }
                } catch {
                    showAlert(message: "Error logging in. Please try again.")
                }
            }
        }

        func navigateToHome() {
            let storyboard = UIStoryboard(name: "Home", bundle: nil)
            let HomeTBC = storyboard.instantiateViewController(withIdentifier: "tabBarVC") as! UITabBarController
            HomeTBC.modalPresentationStyle = .fullScreen
            present(HomeTBC, animated: true)
        }

        func showAlert(message: String) {
            let alert = UIAlertController(title: "Login Failed", message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default))
            present(alert, animated: true)
        }
    
}
