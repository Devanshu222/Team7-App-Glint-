struct Activity {
    let title: String
    let description: String
    let image: String
}
