//
//  ViewController.swift
//  GlintParentalGame
//
//  Created by Tushita Srivastava(Chitkara) on 19/01/25.
//

import UIKit


class ParentalGamesViewController: UIViewController {
    @IBOutlet weak var tableView: UITableView!
    
    // Add completion handler property
    var completionHandler: (() -> Void)?
    
    // Add a property to track the current game title
    var currentGameTitle: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        checkCompletionStatus() // Check if all steps are completed
        updateProgress()
        
        // Add close button if needed
        if presentingViewController != nil {
            let closeButton = UIBarButtonItem(
                title: "Close",
                style: .plain,
                target: self,
                action: #selector(closeButtonTapped)
            )
            navigationItem.rightBarButtonItem = closeButton
        }
        
        // Store the initial title as the current game if it's not "Parental Games"
        if let title = navigationItem.title, title != "Parental Games", title != "🎉 Completed!" {
            currentGameTitle = title
            print("DEBUG: Set currentGameTitle to: \(title)")
        }
    }
    
    @objc private func closeButtonTapped() {
        // Call completion handler before dismissing
        completionHandler?()
        dismiss(animated: true)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        // If being dismissed by other means (e.g., swipe down)
        if isBeingDismissed {
            completionHandler?()
        }
    }
} 

// MARK: - UITableView DataSource & Delegate
extension ParentalGamesViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return steps.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "StepCell", for: indexPath) as! StepCell
        let step = steps[indexPath.row]
        cell.configure(with: step, stepNumber: indexPath.row + 1)
        cell.delegate = self
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    private func updateProgress() {
            let completedSteps = steps.filter { $0.markedDone }.count
            let totalSteps = steps.count
            //progressLabel.text = "Progress: \(completedSteps)/\(totalSteps)"
            
            if completedSteps == totalSteps {
                showCompletionUI()
            } else {
                resetUI()
            }
        }
        private func showCompletionUI() {
            self.view.backgroundColor = UIColor.systemGreen.withAlphaComponent(0.2)
            self.navigationItem.title = "🎉 Completed!"
        }
        
        private func resetUI() {
            self.view.backgroundColor = .white
            self.navigationItem.title = "Parental Games"
        }
    private func checkCompletionStatus() {
        let completedSteps = steps.filter { $0.markedDone }.count
        let totalSteps = steps.count
        
        if completedSteps == totalSteps {
            self.navigationItem.title = "🎉 Completed!"
            self.view.backgroundColor = UIColor.systemGreen.withAlphaComponent(0.2)
        } else {
            self.navigationItem.title = "Parental Games"
            self.view.backgroundColor = .white
        }
    }
}

// MARK: - StepCell Delegate
extension ParentalGamesViewController: StepCellDelegate {
    func stepCircleTapped(at index: Int) {
        guard let cell = tableView.cellForRow(at: IndexPath(row: index, section: 0)) as? StepCell else { return }
        steps[index].markedDone.toggle()
        saveSteps() // Persist state
        cell.animateCircle()
        updateProgress()
        
        // Use the currentGameTitle instead of navigationItem.title
        let gameTitle = currentGameTitle ?? navigationItem.title
        print("DEBUG: Step tapped for game \(gameTitle ?? "Unknown")")
        
        // Check if steps are partially complete
        let completedSteps = steps.filter { $0.markedDone }.count
        let totalSteps = steps.count
        print("DEBUG: Completed \(completedSteps) of \(totalSteps) steps")
        
        if completedSteps > 0 && completedSteps < totalSteps {
            // Check if game is partially complete and add to Jump Back In if needed
            if let gameTitle = gameTitle, !gameTitle.contains("Completed") {
                // Use the new findGameByTitle function for better matching
                if let activity = UserDataManager.shared.findGameByTitle(gameTitle) {
                    print("DEBUG: Found matching activity: \(activity.title)")
                    UserDataManager.shared.addIncompleteParentalGame(activity)
                } else {
                    print("DEBUG: Creating default parental game for Jump Back In")
                    
                    // Create a default parental game entry 
                    let defaultParentalGame = Activites(
                        title: "Parental Game",
                        subtitle: "Interactive parental guidance game",
                        image: UIImage(systemName: "person.2.fill") ?? defaultImage,
                        icon: UIImage(systemName: "house.fill") ?? defaultImage,
                        backgroundColor: UIColor.systemBlue,
                        category: .interactive,
                        isFavourite: false,
                        isParental: true
                    )
                    
                    // Add the default game to Jump Back In
                    UserDataManager.shared.addIncompleteParentalGame(defaultParentalGame)
                }
            }
        }
    }
}

