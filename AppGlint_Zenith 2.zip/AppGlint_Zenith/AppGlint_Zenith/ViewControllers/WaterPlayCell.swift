//
//  WaterPlayCell.swift
//  AppGlint_Zenith
//
//  Created by student-2 on 14/01/25.
//

import UIKit

class WaterPlayCell: UICollectionViewCell {
    @IBOutlet weak var imageView: UIImageView!
    
}
