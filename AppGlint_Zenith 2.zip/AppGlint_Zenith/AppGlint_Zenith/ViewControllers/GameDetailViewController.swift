import UIKit

class GameDetailViewController: UIViewController {
    
    // MARK: - Properties
    var activity: Activites?
    
    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        // Setup code goes here
    }
    
    // MARK: - Private Methods
    private func showInstructions() {
        guard let activity = activity else { return }
        
        let alert = UIAlertController(title: "Game Instructions", message: "This is a parental-guided game. Here's how to play:\n\n1. Find a quiet space with your child\n2. Explain the rules of \(activity.title)\n3. \(activity.subtitle)\n4. Provide encouragement and support throughout", preferredStyle: .alert)
        
        alert.addAction(UIAlertAction(title: "Start Playing", style: .default) { [weak self] _ in
            print("DEBUG: Starting parental game: \(activity.title)")
            // Check if there are any existing incomplete steps
            let completedSteps = steps.filter { $0.markedDone }.count
            let totalSteps = steps.count
            
            print("DEBUG: Current step status: \(completedSteps) of \(totalSteps) completed")
            
            // Navigate to the ParentalGamesViewController to play the game
            if let storyboard = UIStoryboard(name: "Parental", bundle: nil).instantiateInitialViewController() as? UINavigationController,
               let parentalGameVC = storyboard.topViewController as? ParentalGamesViewController {
                print("DEBUG: Setting title on ParentalGamesViewController: \(activity.title)")
                
                // Set both the navigation title and our custom currentGameTitle property
                parentalGameVC.navigationItem.title = activity.title
                parentalGameVC.currentGameTitle = activity.title
                
                print("DEBUG: Set currentGameTitle to: \(activity.title)")
                parentalGameVC.modalPresentationStyle = .fullScreen
                
                // Add a completion handler to check for incomplete games when the view is dismissed
                parentalGameVC.completionHandler = {
                    print("DEBUG: ParentalGamesViewController dismissed")
                    let updatedCompletedSteps = steps.filter { $0.markedDone }.count
                    print("DEBUG: Updated steps status: \(updatedCompletedSteps) of \(totalSteps) completed")
                    
                    // If some steps are completed but not all, add to Jump Back In
                    if updatedCompletedSteps > 0 && updatedCompletedSteps < totalSteps {
                        print("DEBUG: Adding to Jump Back In after dismissal")
                        
                        // Always use the activity from GameDetailViewController if available
                        if activity.isParental {
                            UserDataManager.shared.addIncompleteParentalGame(activity)
                        } else {
                            // Create a default parental game as fallback
                            let defaultParentalGame = Activites(
                                title: "Parental Game",
                                subtitle: "Interactive parental guidance game",
                                image: UIImage(systemName: "person.2.fill") ?? defaultImage,
                                icon: UIImage(systemName: "house.fill") ?? defaultImage,
                                backgroundColor: UIColor.systemBlue,
                                category: .interactive,
                                isFavourite: false,
                                isParental: true
                            )
                            UserDataManager.shared.addIncompleteParentalGame(defaultParentalGame)
                        }
                    }
                }
                
                self?.present(storyboard, animated: true)
            }
        })
        
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        
        present(alert, animated: true)
    }
} 
