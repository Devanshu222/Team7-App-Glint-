//
//  AboutUSViewController.swift
//  AppGlint_Zenith
//
//  Created by Devanshu Singh(chitkara)     on 25/03/25.
//

import UIKit
import SwiftUI

class AboutUSViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Create the SwiftUI view
        let aboutUsView = AboutUsView()
        
        // Create a UIHostingController with the SwiftUI view
        let hostingController = UIHostingController(rootView: aboutUsView)
        
        // Add the hosting controller as a child view controller
        addChild(hostingController)
        
        // Add the hosting controller's view to the view hierarchy
        view.addSubview(hostingController.view)
        
        // Set up constraints
        hostingController.view.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            hostingController.view.topAnchor.constraint(equalTo: view.topAnchor),
            hostingController.view.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            hostingController.view.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            hostingController.view.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
        
        // Notify the hosting controller that it has been moved to the current view controller
        hostingController.didMove(toParent: self)
        
        // Set up navigation
        setupNavigation()
    }
    
    private func setupNavigation() {
        // Set navigation title
        navigationItem.title = "About Us"
        
        // Configure navigation bar appearance
        if #available(iOS 13.0, *) {
            let appearance = UINavigationBarAppearance()
            appearance.configureWithOpaqueBackground()
            appearance.backgroundColor = .systemBackground
            navigationController?.navigationBar.standardAppearance = appearance
            navigationController?.navigationBar.scrollEdgeAppearance = appearance
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
