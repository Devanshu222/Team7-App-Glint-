//
//  CreateAccountViewController.swift
//  AppGlint_Zenith
//
//  Created by Devanshu Singh(chitkara) on 10/12/24.
//

import UIKit

class CreateAccountViewController: UIViewController {
    
    @IBOutlet weak var childName: UITextField!
    @IBOutlet weak var childAgeDatePicker: UIDatePicker!
    @IBOutlet weak var parentEmail: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var confirmPasswordTextField: UITextField!
    @IBOutlet weak var CreateView: UIView!
    
    let alertservice = AlertService()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        /// Customizations for CreateView
        CreateView.backgroundColor = .white
        CreateView.layer.borderWidth = 1.5
        CreateView.layer.borderColor = UIColor.black.cgColor
        CreateView.layer.cornerRadius = 10.0
        CreateView.layer.shadowColor = UIColor.gray.cgColor
        CreateView.layer.shadowOpacity = 0.5
        CreateView.layer.shadowOffset = CGSize(width: 2, height: 2.5)
        
        /// Secure password fields
        passwordTextField.isSecureTextEntry = true
        //confirmPasswordTextField.isSecureTextEntry = true
    }
    
    @IBAction func signUpButtonTapped(_ sender: Any) {
        Task { @MainActor in
            // Safely unwrap text fields and date picker
            guard let name = childName.text, !name.isEmpty,
                  let email = parentEmail.text, !email.isEmpty,
                  let password = passwordTextField.text, !password.isEmpty
            else {
                showAlert(title: "Error", message: "Please fill in all required fields.")
                return
            }
            
            // Validate password strength (ONLY for passwordTextField)
            if !isValidPassword(password) {
                showAlert(title: "Invalid Password", message: "Password must be at least 8 characters, contain one uppercase letter and one number.")
                return
            }
            
            // Check if passwords match (Confirm password should match password)
//            if password != confirmPassword {
//                showAlert(title: "Error", message: "Passwords do not match.")
//                return
//            }
            
            let selectedAgeDate = childAgeDatePicker.date
            let age = calculateAge(from: selectedAgeDate)
            
            // Save user data
            await UserDataManager.shared.saveUserData(childName: name, childAge: age, parentEmail: email, phone: "", password: password)
            
            // Print user data for debugging
            if let userData = UserDataManager.shared.getUserData() {
                print("Child Name: \(userData.childName)")
                print("Child Age: \(userData.childAge)")
                print("Parent Email: \(userData.parentEmail)")
            }
            
            // Show success alert or go to next screen
            let alertVC = alertservice.alert()
            present(alertVC, animated: true)
        }
    }
    
    func calculateAge(from dateOfBirth: Date) -> Int {
        let calendar = Calendar.current
        let ageComponents = calendar.dateComponents([.year], from: dateOfBirth, to: Date())
        return ageComponents.year ?? 0
    }
    
    // ✅ Password validation only for the password field
    func isValidPassword(_ password: String) -> Bool {
        let passwordRegex = "^(?=.*[A-Z])(?=.*[0-9]).{8,}$"
        return NSPredicate(format: "SELF MATCHES %@", passwordRegex).evaluate(with: password)
    }
    
    func showAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
}
